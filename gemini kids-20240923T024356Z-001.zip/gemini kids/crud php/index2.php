
<?php
include("../../conexion.php");



$stm=$conexion->prepare("SELECT * FROM contactos");
$stm->execute();
$contactos=$stm->fetchALL(PDO::FETCH_ASSOC);

?>


<?php incluide("../../template/header.php"); ?>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#create">
 Nuevo
</button>
<div class="table-responsive">
    <table class="table">
        <thead class="table table-dark">>
            <tr>
                <th scope="col">Nombre</th>
                <th scope="col">Clave</th>
                <th scope="col">tipo de usuario</th>
                <th>fecha</th>
                <th>acciones</th>

            </tr>
        </thead>
        <tbody>
            <?php foreach($contactos as $contacto) { ?>
            <tr class="">
                <td scope="row"><?php echo $contacto ['usuario']; ?></td>
                <td><?php echo $contacto ['contraseña'];?></td>
                <td><?php echo $contacto ['tipo de usuario']; ?></td>
                <td><?php echo $contacto['fecha']; ?></td>
                <td>editar|eliminar</td>
            </tr>
            <tr class="">
                <td scope="row">Item</td>
                <td>Item</td>
                <td>Item</td>
            </tr>
     <?php  } ?> </tbody>
    </table>
</div>
<?php incluide("create-php"); ?>

<?php incluide("../../template/footer.php"); ?>
