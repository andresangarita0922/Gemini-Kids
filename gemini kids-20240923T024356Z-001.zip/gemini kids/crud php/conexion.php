<?php

$servidor="localhost";
$db="phpcrud";
$username="root";
$password="password";

try {
 $conexion=new PDO("mysql:host=$servidor;dbname=proyecto04",$username,$password);


}catch (Exception $e) {
    echo $e->getMessage();
}

