<?php
include ('modeloConexion.php');
class modeloVenta extends modeloConexion
{
    //ATRIBUTOS
    private $ventaCodigoV;
    private $fechaVentaV;
    private $cantidadVentaV;
    private $ventaTotalV;
    private $admi_codigoV;
    private $clie_codigoV;


    //METODO CONSTRUCTOR
    function __construct($ventaCodigoIn, $fechaVentaIn, $cantidadVentaIn,$ventaTotalIn, $admi_codigoIn,
                        $clie_codigoIn)
    {
            $this->ventaCodigoV = $ventaCodigoIn;
            $this->fechaVentaV = $fechaVentaIn;
            $this->cantidadVentaV = $cantidadVentaIn;
            $this->ventaTotalV = $ventaTotalIn;
            $this->admi_codigoV = $admi_codigoIn;
            $this->clie_codigoV = $clie_codigoIn;        
    }
//INSERTAR
    public function insertarVenta(){
        $objConexion = new modeloConexion();
        $objPDO = $objConexion::conectar();
    
        try {
            $sql = $objPDO->prepare("CALL insertarVenta
                                        (:ventaCodigoV,
                                         :fechaVentaV,
                                         :cantidadVentaV,
                                         :ventaTotalV,
                                         :admi_codigoV,
                                         :clie_codigoV);");
            $sql->bindparam(':ventaCodigoV',$this->ventaCodigoV);
            $sql->bindparam(':fechaVentaV',$this->fechaVentaV);
            $sql->bindparam(':cantidadVentaV',$this->cantidadVentaV);
            $sql->bindparam(':ventaTotalV',$this->ventaTotalV);
            $sql->bindparam(':admi_codigoV',$this->admi_codigoV);
            $sql->bindparam(':clie_codigoV',$this->clie_codigoV);
    
            $sql->execute();
    
            $objPDO = $objConexion::desconectar();
        } catch (\Throwable $error) {
            echo 'ERROR: '. $error->getMessage();
            die();
        }
    }
    //LISTAR VENTA
    function consultarVenta(){
        $objConexion = new modeloConexion();
        $objPDO = $objConexion::conectar();
                                            
         try {
            $sql= $objPDO->prepare("CALL listarVenta"); 
    
              $sql->execute();
              return $sql->fetchAll(PDO::FETCH_OBJ);
    
               $objPDO=$objConexion::desconectar();
         }
             
         
           catch(\Throwable $error){
               echo'ERROR:'. $error -> getMessage();
               die();
               
           }
           
    }
         //ACTUALIZAR VENTA
         public function consultarVentaxID(){ 
            $objConexion = new modeloConexion(); 
            $objPDO = $objConexion::conectar();
    
            try {
        
                $sql = $objPDO->prepare("CALL consultarxId(:codigoVenta);");
                
                $sql->bindparam(':codigoVenta', $this->ventaCodigoV);
                
                $sql->execute(); 
    
                return $sql->fetchAll(PDO::FETCH_OBJ);
                
                $objPDO= $objConexion::desconectar(); 
            }
        
            catch (\Throwable $error) {
                echo 'ERROR: '. $error->getMessage();          
                die();
            }
        
        }
    
        public function actualizarVenta(){
            $objConexion = new modeloConexion();
            $objPDO = $objConexion::conectar();
        
            try {
                $sql = $objPDO->prepare("CALL actualizarVenta
                                            (:ventaCodigoV,
                                             :fechaVentaV,
                                             :cantidadVentaV,
                                             :ventaTotalV,
                                             :admi_codigoV,
                                             :clie_codigoV);");
                $sql->bindparam(':ventaCodigoV',$this->ventaCodigoV);
                $sql->bindparam(':fechaVentaV',$this->fechaVentaV);
                $sql->bindparam(':cantidadVentaV',$this->cantidadVentaV);
                $sql->bindparam(':ventaTotalV',$this->ventaTotalV);
                $sql->bindparam(':admi_codigoV',$this->admi_codigoV);
                $sql->bindparam(':clie_codigoV',$this->clie_codigoV);
        
                $sql->execute();
        
                $objPDO = $objConexion::desconectar();
            } catch (\Throwable $error) {
                echo 'ERROR: '. $error->getMessage();
                die();
            }
        }
            //ELIMINAR
     public function eliminarVenta(){
        $objConexion= new modeloConexion();
        $objPDO=$objConexion::conectar();
    
        try {
            $sql = $objPDO->prepare("CALL eliminarVenta
                                     (:ventaCodigo);");
            $sql->bindparam(':ventaCodigo',$this->ventaCodigoV);
            $sql->execute();
            $objPDO=$objConexion::desconectar();
        }   catch(\Throwable$error){
            echo'ERROR:'.$error->getMessage();
            die();
        }    
    }
}

?>