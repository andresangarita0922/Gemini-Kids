<?php

//NOMBRE CLASE 
include("modeloConexion.php");

class modelosUsuario extends modeloConexion{

    //ATRIBUTOS
    private $codigo=0;
    private $nombre="texto";
    private $clave=0;
    private $tipoUsuario="texto";

    //ENCAPSULAR
    function __construct($codigoIN,$nombreIN,$claveIN, $tipoUsuarioIN)
    {
        $this->codigo=$codigoIN;
        $this->nombre=$nombreIN;
        $this->clave=$claveIN;
        $this->tipoUsuario = $tipoUsuarioIN; 
    }

    //METODOS
    public function consultaLogin()
    {
        $objConexion = new modeloConexion();
        $objPDO = $objConexion:: conectar();
            try {
                $sql = $objPDO->prepare('SELECT nombre, clave, tipoUsuario FROM usuario
                                        WHERE nombre = :nombre');
                $sql->bindparam(':nombre', $this->nombre);
                $sql->execute();
                return $sql->fetch(PDO::FETCH_OBJ);
                $objPDO = $objConexion::desconectar();
                                                    
            } catch (\Throwable $error) {
                echo 'ERROR:' . $error->getMessage();
                die();
            }
    }

    //METODOS CLASE 
    public function registrarUsuario()
    {
        $objConexion = new modeloConexion(); 
        $objPDO = $objConexion::conectar();
        
        try {
            $sql = $objPDO->prepare("INSERT INTO usuario VALUES
                                        (
                                            :codigo,
                                            :nombre,
                                            :clave,
                                            :tipoUsuario
                                        );"); 
            $sql->bindparam(':codigo',$this->codigo); 
            $sql->bindparam(':nombre',$this->nombre);
            $sql->bindparam(':clave',$this->clave);
            $sql->bindparam(':tipoUsuario',$this->tipoUsuario);
          

            $sql->execute(); 

            $objPDO = $objConexion::desconectar(); 

        } catch (\Throwable $error) {
            echo("Error modelo!; ".$error->getMessage());
            die();
        }
    }

//listar Producto
    function listarUsuario(){
        $objConexion = new modeloConexion();
        $objPDO = $objConexion::conectar();
                                            
         try {
            $sql= $objPDO->prepare("SELECT * FROM usuario"); 
    
              $sql->execute();
              return $sql->fetchAll(PDO::FETCH_OBJ);
    
               $objPDO=$objConexion::desconectar();
         }
             
         
           catch(\Throwable $error){
               echo'ERROR:'. $error -> getMessage();
               die();
               
           }
           
    }

   

    //actualizar producto
    public function consultarUsuario(){ 
        $objConexion = new modeloConexion(); 
        $objPDO = $objConexion::conectar();

        try {
    
            $sql = $objPDO->prepare("SELECT * FROM usuario
                                    WHERE codigo=:codigo");
            
            $sql->bindparam(':codigo', $this->codigo);
            
            $sql->execute(); 

            return $sql->fetchAll(PDO::FETCH_OBJ);
            
            $objPDO= $objConexion::desconectar(); 
        }
    
        catch (\Throwable $error) {
            echo 'ERROR: '. $error->getMessage();          
            die();
        }
    
    }

    //actualizar
    public function actualizarUsuario(){
        $objConexion= new modeloConexion();
        $objPDO=$objConexion::conectar();
        try{
            $sql=$objPDO->prepare("UPDATE usuario SET
                                     nombre=:nombre,
                                     clave=:clave,
                                     tipoUsuario=:tipoUsuario
                                     WHERE codigo=:codigo;");
            $sql->bindparam(':codigo',$this->codigo);
            $sql->bindparam(':nombre',$this->nombre);
            $sql->bindparam(':clave',$this->clave);
            $sql->bindparam(':tipoUsuario',$this->tipoUsuario);
           
            
            $sql->execute();

            $objPDO = $objConexion::desconectar();
    } catch (\Throwable $error) {
        echo 'ERROR: '. $error->getMessage();          
        die();
    }
    
    }

     //eliminar 
     public function eliminarUsuario(){
        $objConexion= new modeloConexion();
        $objPDO=$objConexion::conectar();
    
        try {
            $sql = $objPDO->prepare("DELETE FROM usuario 
                                        WHERE codigo = :codigo;");
            $sql->bindparam(':codigo',$this->codigo);
            $sql->execute();
            $objPDO=$objConexion::desconectar();
        }   catch(\Throwable$error){
            echo'ERROR:'.$error->getMessage();
            die();
        }    
    }

}
?>