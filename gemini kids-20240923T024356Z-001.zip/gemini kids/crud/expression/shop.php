<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tienda</title>

    <link rel="stylesheet" href="assets/css/shop.css">

    <link rel="stylesheet" href="assets/css/estilo.css">

     <link rel="icon" href="assets/img/logo.ico">
     
     <link rel="stylesheet" href="assets/css/fontello.css">

     <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">


</head>
<body>
    
    
<!--header section starts-->

<header>

    <div id="menu-bar" class="fas fa-bars"></div>
  
    <a href="index.php" class="logo"><i class="icon-tags"></i>EXPRESSION DIGITAL</a>

  
    <div class="icons-header">
      <a href="#" class="fas fa-heart"></a>
      <a href="#" class="fas fa-user"></a>
    </div>
  
   </header>
  
  <!--header section ends-->


  <!--home section starts-->

 <section class="home" id="home">

  <div class="content">
    <h3 class="heading"> <span> Aquí encontraras </span> los mejores descuentos!</h3> 
    <p>Esta sección esta dedicada para que conozcas los mejores descuentos en todos tus productos favoritos. 
      actualizamos cada que haya una oferta de tu agrado. Estamos seguros que hayaras lo que buscas!</p>
  </div>

  <div class="image">
    <img src="assets/img/d_pulpo2.png" alt="serpiente">
  </div>

 </section>

<!--home section ends-->



  <!--products section starts-->

  <section class="products-1" id="products-1">

  <h1 class="heading-1"> mejores <span> productos</span></h1>

  <div class="box-container-1">

    <div class="box-1">
      <span class="discount">-10%</span>
      <div class="image">
        <img src="assets/img/c_kokoro.jpeg" alt="">
        
        <div class="icons-1">
          <a href="#" class="fas fa-heart"></a>
          <a href="#" class="cart-btn">comprar</a>
          <a href="#" class="fas fa-share"></a>

        </div>
        <div class="content-1">
          <h3 class="price">$50.000 <span>$80.000</span></h3>
        </div>
      </div>
    </div>


    <div class="box-1">
      <span class="discount">-10%</span>
      <div class="image">
        <img src="assets/img/c_mami.jpeg" alt="">
        
        <div class="icons-1">

          <a href="#" class="fas fa-heart"></a>
          <a href="#" class="cart-btn">comprar</a>
          <a href="#" class="fas fa-share"></a>

        </div>
        <div class="content-1">
          <h3 class="price">$50.000 <span>$80.000</span></h3>
        </div>
      </div>
    </div>


    <div class="box-1">
      <span class="discount">-10%</span>
      <div class="image">
        <img src="assets/img/lapicero.jpeg" alt="">
        
        <div class="icons-1">

          <a href="#" class="fas fa-heart"></a>
          <a href="#" class="cart-btn">comprar</a>
          <a href="#" class="fas fa-share"></a>

        </div>
        <div class="content-1">
          <h3 class="price">$50.000 <span>$80.000</span></h3>
        </div>
      </div>
    </div>


    <div class="box-1">
      <span class="discount">-10%</span>
      <div class="image">
        <img src="assets/img/variados.jpeg" alt="">
        
        <div class="icons-1">

          <a href="#" class="fas fa-heart"></a>
          <a href="#" class="cart-btn">comprar</a>
          <a href="#" class="fas fa-share"></a>

        </div>
        <div class="content-1">
          <h3 class="price">$50.000 <span>$80.000</span></h3>
        </div>
      </div>
    </div>


    <div class="box-1">
      <span class="discount">-10%</span>
      <div class="image">
        <img src="assets/img/c_corazón.jpg" alt="">
        
        <div class="icons-1">

          <a href="#" class="fas fa-heart"></a>
          <a href="#" class="cart-btn">comprar</a>
          <a href="#" class="fas fa-share"></a>

        </div>
        <div class="content-1">
          <h3 class="price">$50.000 <span>$80.000</span></h3>
        </div>
      </div>
    </div>


    <div class="box-1">
      <span class="discount">-10%</span>
      <div class="image">
        <img src="assets/img/i_años.jpg" alt="">
        
        <div class="icons-1">

          <a href="#" class="fas fa-heart"></a>
          <a href="#" class="cart-btn">comprar</a>
          <a href="#" class="fas fa-share"></a>

        </div>
        <div class="content-1">
          <h3 class="price">$50.000 <span>$80.000</span></h3>
        </div>
      </div>
    </div>


    <div class="box-1">
      <span class="discount">-10%</span>
      <div class="image">
        <img src="assets/img/c_expandible.jpg" alt="">
        
        <div class="icons-1">

          <a href="#" class="fas fa-heart"></a>
          <a href="#" class="cart-btn">comprar</a>
          <a href="#" class="fas fa-share"></a>

        </div>
        <div class="content-1">
          <h3 class="price">$50.000 <span>$80.000</span></h3>
        </div>
      </div>
    </div>


    <div class="box-1">
      <span class="discount">-10%</span>
      <div class="image">
        <img src="assets/img/c_madre.jpg" alt="">
        
        <div class="icons-1">

          <a href="#" class="fas fa-heart"></a>
          <a href="#" class="cart-btn">comprar</a>
          <a href="#" class="fas fa-share"></a>

        </div>
        <div class="content-1">
          <h3 class="price">$50.000 <span>$80.000</span></h3>
        </div>
      </div>
    </div>


    <div class="box-1">
      <span class="discount">-10%</span>
      <div class="image">
        <img src="assets/img/cesta.jpg" alt="">
        
        <div class="icons-1">

          <a href="#" class="fas fa-heart"></a>
          <a href="#" class="cart-btn">comprar</a>
          <a href="#" class="fas fa-share"></a>

        </div>
        <div class="content-1">
          <h3 class="price">$50.000 <span>$80.000</span></h3>
        </div>


        
      </div>
    </div>



  </div>
</section>

  <!--products section ends-->





  
  <!--footer section starts-->

 <section class="footer">

    <div class="box-container">
   
   
   
   <div class="box">
     <i class="fas fa-phone"></i>
   
     <h3>nuestros medios de contacto</h3>
     <p>3005548390</p>
     <p>Expressión.digital@gmail.com</p>
    </div>
   
   
    
    <div class="box">
     <i class="fas fa-clock"></i>
   
     <h3>horario de apertura</h3>
     <p>08:00am - 06:00pm</p>
    </div>
   
   
   
    <div class="box">
     <i class="fas fa-map-marker-alt"></i>
   
     <h3>ubicación de la tienda</h3>
     <p>colombia, bogotá - Los Mártires</p>
    </div>
   
   
   
    </div>
   
    <div class="credit"> &copy; copyright @ 2022 - 2023 by <span> mr. web designer - Linda & Erick </span> | reservados todos los derechos | </div>
   
   </section>
   
   <!--footer section ends-->
   
   
   <!--scroll button starts-->
   
   <a href="#home" class="fas fa-angle-up" id="scroll-top"></a> 
   
   <!--scroll button ends-->
   
   
   <!--loader stars-->
   
   <div class="loader-container">
     <img src="assets/img/loader.gif" alt="">
   </div>
   
   <!--loader ends-->
   
   
   <script src="assets/js/script.js"></script>


</body>
