<!doctype html>
<html lang="en">

<head>

  <title>Register</title>

  <!-- Required meta tags -->

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->

  <link rel="stylesheet" href="../assets/css/login.css">

<link rel="stylesheet" href="../assets/css/estilo.css">

 <link rel="icon" href="../assets/img/logo.ico">
 
 <link rel="stylesheet" href="../assets/css/fontello.css">

 <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

</head>

<body>

<header>

<div id="menu-bar" class="fas fa-bars"></div>

<a href="../index.html" class="logo"><i class="icon-tags"></i>EXPRESSION DIGITAL</a>

<div class="icons-header">
  <a href="#" class="fas fa-heart"></a>
  <a href="../shop.html" class="fas fa-shopping-cart"></a>
</div>

</header>

<div class="box">
  <form action="add.php" method="post">
    <h1>Ingresa tus datos</h1>

        <div class="inputBox">
            <input type="text" required="required" id="form1Example13" class="form-control form-control-lg py-3" name="name" autocomplete="off">
            <span>nombre</span>
            <i></i>
        </div>

        <div class="inputBox">
            <input type="text" required="required" id="form1Example13" class="form-control form-control-lg py-3" name="username" autocomplete="off">
            <span>correo</span>
            <i></i>
        </div>

        <div class="inputBox">
            <input type="password" required="required" id="form1Example23" class="form-control form-control-lg py-3" name="password" autocomplete="off">
            <span>Contraseña</span>
            <i></i>
        </div>
        
          <input type="submit" value="Register" name="register">

      </div>
  </form>
</div>

<!--loader stars-->

<div class="loader-container">
  <img src="../assets/img/loader.gif" alt="">
</div>

<!--loader ends-->

    <script src="../assets/js/script.js"></script>

</body>

</html>