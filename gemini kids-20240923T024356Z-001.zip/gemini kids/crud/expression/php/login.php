<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>¡COMENCEMOS!</title>

    <link rel="stylesheet" href="../assets/css/login.css">

    <link rel="stylesheet" href="../assets/css/estilo.css">

     <link rel="icon" href="../assets/img/logo.ico">
     
     <link rel="stylesheet" href="../assets/css/fontello.css">

     <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

</head>

<body>
 
<!--header section starts-->

<header>

<div id="menu-bar" class="fas fa-bars"></div>

<a href="../index.php" class="logo"><i class="icon-tags"></i>EXPRESSION DIGITAL</a>

<div class="icons-header">
  <a href="#" class="fas fa-heart"></a>
  <a href="../shop.php" class="fas fa-shopping-cart"></a>
</div>

</header>
  
  <!--header section ends-->
  
  <!--login section starts-->

  <div class="box">
        
    <form action="../controladores/controladorInicioSesion.php" method="post">
        <h1>Inicia Tú Sesión</h1>
        
        <div class="inputBox">
            <input type="text" required="required" id="form1Example13" class="form-control form-control-lg py-3" name="usuario" autocomplete="off">
            <span>Usuario</span>
            <i></i>
        </div>

        <div class="inputBox">
            <input type="password" required="required" id="form1Example23" class="form-control form-control-lg py-3" name="clave" autocomplete="off">
            <span>Contraseña</span>
            <i></i>
        </div>

        <div class="links">
            <a href="register.php">Regístrate Aquí</a>
        </div>

        <input type="submit" value="Sign in" name="login">

    </form>
</div>

<a href="#home" class="fas fa-angle-up" id="scroll-top"></a> 

<!--loader stars-->

<div class="loader-container">
  <img src="../assets/img/loader.gif" alt="">
</div>

<!--loader ends-->



    <script src="../assets/js/script.js"></script>

</body>
</html>