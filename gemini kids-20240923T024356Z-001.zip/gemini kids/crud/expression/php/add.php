<?php
include_once('connection.php');

if(isset($_POST['register']))
{
    $name=$_POST['name'];
    $username=$_POST['username'];
    $password=md5($_POST['password']);

    $sql   ="INSERT INTO `usuario`(`usua_nombre`, `usua_nombre_usuario`, `usua_comtraseña`) VALUES ('$name','$username','$password')";
    $result=mysqli_query($conn,$sql);
    if($result){ 
    header('location:login.php');
    echo"<script>alert('New User Register Success');</script>";   
    }else{
        die(mysqli_error($conn)) ;
    }
   
}
