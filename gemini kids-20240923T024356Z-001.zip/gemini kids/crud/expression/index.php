
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXPRESSION DIGITAL</title>

     <link rel="stylesheet" href="assets/css/estilo.css">

     <link rel="icon" href="assets/img/logo.ico">
     
     <link rel="stylesheet" href="assets/css/fontello.css">

     <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

     <link rel="stylesheet" href="assets/index.php">


</head>
<body>


<!--header section starts-->

 <header>

  <div id="menu-bar" class="fas fa-bars"></div>

  <a href="#" class="logo"><i class="icon-tags"></i>EXPRESSION DIGITAL</a>

  <nav class="navbar">
    <a href="#home">home</a>
    <a href="#about">acerca de</a>
    <a href="#products">productos</a>
    <a href="#gallery">galeria</a>
    <a href="#team">team</a>
    <a href="#contac">comentanos</a>
  </nav>

  <div class="icons-header">
    <a href="#" class="fas fa-heart"></a>
    <a href="shop.php" class="fas fa-shopping-cart"></a>
    <a href="php/login.php" class="fas fa-user"></a>
  </div>

 </header>

<!--header section ends-->


<!--home section starts-->

<section class="home" id="home">

  <div class="content">
    <h3 class="heading"> <span> Para innovadores </span> como tú!</h3> 
    <p>oye tú, si tú! eres especial para nosotros por eso te ofrecemos productos 
      de alta calidad a diferentes precios, para diversas ocaciones y para todo tipo
      de gustos. Sigue bajando y conoceras los que te ofrecemos para innovar tu vida.</p>
    <a href="#" class="btn">compra aquí</a>
  </div>

  <div class="image">
    <img src="assets/img/home-img.png" alt="serpiente">
  </div>

</section>

<!--home section ends-->


<!--about section starts-->

<section class="about" id="about">

 <h1 class="heading-1"> <span> acerca </span> de.. </h1>

 <div class="row">

  <div class="video-container">
    <video src="assets/img/about-vid.mp4" loop autoplay muted></video>
    <h3>lo mejor en productos a base de madera mdf</h3>
  </div>

  <div class="content">
    <h3>por qué elegirnos?</h3>
    <p>
      estamos 100% dedicados a ofrecerte lo mejor en diseños en madera para todo tipo de gustos!</p>
    <p>Si no te gustan los productos que ves.. no hay problema! También nos puedes comentar 
      que deseas en la sección de comentarios ya que ofrecemos venta de productos personalizados.
      Esperamos ofrecete un excelente servicio de calidad.</p>

      <a href="#" class="btn">conoce más aquí</a>

  </div>

 </div>

</section>

<!--about section ends-->


<!--products section starts-->

<section class="products" id="products">

  <h1 class="heading-1"> los <span>productos</span> mas buscados </h1>

  <div class="box-container">

    <div class="box">
      <span class="price"> $10.000 - $40.000 </span>
      <img src="assets/img/c_corazón.jpg" alt="caja corazón">
      <h3>caja - corazón</h3>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>

      <a href="#" class="btn">solicita aquí</a>

    </div>

    <div class="box">
      <span class="price"> $10.000 - $40.000 </span>
      <img src="assets/img/c_expandible.jpg" alt="caja expandible">
      <h3>caja expandible</h3>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>

      <a href="#" class="btn">solicita aquí</a>

    </div>

    <div class="box">
      <span class="price"> $10.000 - $40.000 </span>
      <img src="assets/img/d_elefante.jpg" alt="elefante hindú decorativo">
      <h3>elefante hindú decorativo</h3>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>

      <a href="#" class="btn">solicita aquí</a>

    </div>

    <div class="box">
      <span class="price"> $10.000 - $40.000 </span>
      <img src="assets/img/i_años.jpg" alt="invitación">
      <h3>días especiales - invitación</h3>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>

      <a href="#" class="btn">solicita aquí</a>

    </div>

    <div class="box">
      <span class="price"> $5.000 - $40.000 </span>
      <img src="assets/img/p_2.jpg" alt="portacelular - tablet">
      <h3>portacelular - portatablet</h3>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>

      <a href="#" class="btn">solicita aquí</a>

    </div>
    
    <div class="box">
      <span class="price"> $10.000 - $40.000 </span>
      <img src="assets/img/reloj.png" alt="reloj gato">
      <h3>reloj gato</h3>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>

      <a href="#" class="btn">solicita aquí</a>

    </div>


  </div>

</section>

<!--products section ends-->


<!--forma pago section starts-->

<section class="iconsfp-container">

  <div class="iconsfp">
    <img src="assets/img/icon-1.png" alt="">
    <div class="info">
      <h3>envio de costo bajo</h3>
      <span>en todos los pedidos</span>
    </div>
  </div>


  <div class="iconsfp">
    <img src="assets/img/icon-2.png" alt="">
    <div class="info">
      <h3>devolución en max 10 días</h3>
      <span>garantía de devolución del dinero</span>
    </div>
  </div>


  <div class="iconsfp">
    <img src="assets/img/icon-3.png" alt="">
    <div class="info">
      <h3>ofertas y regalos</h3>
      <span>en todos los pedidos</span>
    </div>
  </div>


  <div class="iconsfp">
    <img src="assets/img/icon-4.png" alt="">
    <div class="info">
      <h3>pagos seguros</h3>
      <span>protección las 24h</span>
    </div>
  </div>


</section>

<!--forma pago section ends-->


<!--gallery section starts-->

<section class="gallery" id="gallery">

 <h1 class="heading-1"> nuestra <span> galeria </span></h1>

 <div class="box-container">

   <div class="box">
    <img src="assets/img/c_madre.jpg" alt="">
    <div class="content">
      <h3>caja - Mother Day</h3>
      <p>para obsequiarle a nuestra querida madre en su día.</p>
        <a href="#" class="btn">obtenlo aquí</a>
    </div>
   </div>

   <div class="box">
    <img src="assets/img/cesta.jpg" alt="">
    <div class="content">
      <h3>caja - cesta</h3>
      <p>ofrece un diseño y espacio para dejar tus mejores recuerdos.</p>
        <a href="#" class="btn">obtenlo aquí</a>
    </div>
   </div>

   <div class="box">
    <img src="assets/img/d_perro.jpg" alt="">
    <div class="content">
      <h3>decoración - perro</h3>
      <p>decora tu pared al estilo canino.</p>
        <a href="#" class="btn">obtenlo aquí</a>
    </div>
   </div>

   <div class="box">
    <img src="assets/img/d_pulpo.jpg" alt="">
    <div class="content">
      <h3>decoración - pulpo</h3>
      <p>decora tu pared a un estilo geométrico y natural.</p>
        <a href="#" class="btn">obtenlo aquí</a>
    </div>
   </div>

   <div class="box">
    <img src="assets/img/p_cel.jpg" alt="">
    <div class="content">
      <h3>portacelular</h3>
      <p>ayuda que te servirá en cualquier momento.</p>
        <a href="#" class="btn">obtenlo aquí</a>
    </div>
   </div>

   <div class="box">
    <img src="assets/img/vitrina.png" alt="">
    <div class="content">
      <h3>vitrina led</h3>
      <p>podrás almacenar cualquier cosa y ser visible en cualquier momento gracias a su función LED.</p>
        <a href="#" class="btn">obtenlo aquí</a>
    </div>
   </div>


 </div>

</section>

<!--gallery section ends-->


<!--team section starts-->

<section class="team" id="team">
  <h1 class="heading-1"> el <span> team </span> administrativo </h1>

  <div class="box-container">

  
    <div class="box">
      <img src="assets/img/pic2.png" alt="">
      <h3>Ayudante</h3>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>"Nos esforzamos para que nuestros clientes queden satisfechos con el producto;
        nos alegra ver que nuestros clientes nos ofrecen buenos comentarios!"</p>
    </div>


<div class="box">
      <img src="assets/img/pic1.png" alt="">
      <h3>Jorge Cardona / Administrador</h3>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>"Mi visión es el crecer ofreciendo cosas que sirvan y dejen una huella
        en nuestros clientes; su fidelidad hacia nosotros nos impulsa para continuar"</p>
    </div>


    <div class="box">
      <img src="assets/img/pic3.png" alt="">
      <h3>Ayudante</h3>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>"Son productos hechos a base de esfuerzo y dedicación, con madera de calidad y medidas perfectas
         para que dejen de que hablar; aceptamos todas sus sugerencias para crecer"</p>
    </div>


  </div>

</section>

<!--team section ends-->


<!--contac section starts-->

<section class="contac" id="contac">

<h1 class="heading-1"><span> comentanos cualquier </span> inquietud o sugerencia </h1>

<div class="row">

 <div class="image">
  <img src="assets/img/contac-img.png" alt="">
 </div>

 <form action="" method="post">

  <div class="inputBox">
    <input type="text" name="name" required="required" placeholder="nombre - apellido">
    <input type="email" name="email" required="required" placeholder="email">
  </div>

  <div class="inputBox">
    <input type="tel" name="number" required="required" placeholder="número telefónico" 
    min="0" max="9999999999" onkeypress="if(this.value.length == 10) return false">

    <input type="text" name="name_p" "required" placeholder="nombre del pedido">
  </div>

 <textarea placeholder="comentario/descripción del pedido" name="descrip" id="" cols="30" rows="10"></textarea>

 <input type="submit" value="enviar" class="btn">

 </form>

</div>

</section>

<!--contac section ends-->


<!--footer section starts-->

<section class="footer">

 <div class="box-container">



<div class="box">
  <i class="fas fa-phone"></i>

  <h3>nuestros medios de contacto</h3>
  <p>3005548390</p>
  <p>Expressión.digital@gmail.com</p>
 </div>


 
 <div class="box">
  <i class="fas fa-clock"></i>

  <h3>horario de apertura</h3>
  <p>08:00am - 06:00pm</p>
 </div>



 <div class="box">
  <i class="fas fa-map-marker-alt"></i>

  <h3>ubicación de la tienda</h3>
  <p>colombia, bogotá - Los Mártires</p>
 </div>



 </div>

 <div class="credit"> &copy; copyright @ 2022 - 2023 by <span> mr. web designer - Linda & Erick </span> | reservados todos los derechos | </div>

</section>

<!--footer section ends-->


<!--scroll button starts-->

<a href="#home" class="fas fa-angle-up" id="scroll-top"></a> 

<!--scroll button ends-->


<!--loader stars-->

<div class="loader-container">
  <img src="assets/img/loader.gif" alt="">
</div>

<!--loader ends-->


<script src="assets/js/script.js"></script>

</body>
</html>
