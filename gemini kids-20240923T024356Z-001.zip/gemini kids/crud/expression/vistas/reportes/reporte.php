<?php
            include ("../../controladores/controladorVenta.php");

            session_start();

            if($_SESSION['usuario']== NULL || $_SESSION['usuario']=="")
            {
                session_destroy();
                header('location ../../index.php');
            }
            else{

                        $listaReporte = reporte();
            }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REPORTE PDF</title>
    <link rel="stylesheet" href="reportePDF.css">
    
</head>
<style>
    body {
        
        background-image: url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQVPiTfHx4ArBO8ICIbEep0JATEEK100pZa2Fw3fwjGGQfWvP10iiO4LdLoxHUi_0PxsjY&usqp=CAU); 
        background-repeat: no-repeat;
        background-size: cover;
    }

</style>

<body>
    
    <center>
        <div>
           
        <marquee behavior="left" direction=""></marquee>
            <br>
            <p>
            <h1>REPORTE DE ASIGNACION DE VENTAS</h1>  <img src="https://cdn-icons-png.flaticon.com/512/2374/2374024.png" alt="" width=200px; height=200px; > 
            </p>

    <center>
        <br>
        <center>
            <div>
                <table border="solid">
                    <thead>
                        <tr>
                            <th>Codigo de la Venta</th>
                            <th>Fecha de la Venta</th>
                            <th>Cantidad Venta</th>
                            <th>Venta Total</th>
                            <th>Codigo del Vendedor</th>
                            <th>Codigo del Cliente</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($listaReporte as $reporte):?>
                        <tr>
                            <td><?php echo $reporte->ventaCodigo?></td>
                            <td><?php echo $reporte->fechaVenta?></td>
                            <td><?php echo $reporte->cantidadVenta?></td>
                            <td><?php echo $reporte->ventaTotal?></td>
                            <td><?php echo $reporte->codigoVendedor?></td>
                            <td><?php echo $reporte->codigoCliente?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    
                </table>
            </div>
            
</body>

</html>

