<?php

session_start(); 

if($_SESSION['usuario']==NULL || $_SESSION['usuario']==""){
    session_destroy(); 
    header("location: ../../index.php");
}
elseif($_SESSION['usuario']=="cliente"){
    session_destroy(); 
    header("location: ../../index.php");
} 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../assets/css/menu.css">
    <title>MENU ADMINISTRADOR</title>
</head>
<body>
    <!-- / My brand -->
<div class='brand'>
  <a href='https://www.jamiecoulter.co.uk' target='_blank'>
    
  </a>
</div>
<!-- / Begin Body -->
<div class='swanky'>
  <!-- / Introduction Block -->
  <div class='swanky_title'>
    <h1>CONOCE NUESTRO MENU</h1>
    <p>Aprende mas sobre nosotros.</p>
<div class='swanky_title__social'>
    <a href="../reportes/generarPDF.php">
        <div class=''>
          <div class='arrow'>
            <div class='stem'></div>
            <div class='point'></div>
          </div>
</div>
        <img src="https://cdn-icons-png.flaticon.com/512/201/201153.png">
         REPORTE PDF
        </a>
  
    <div class='swanky_title__social'>
      <a href='../../controladores/controladorCerrarSesion.php'>
        <div class=''>
          <div class='arrow'>
            <div class='stem'></div>
            <div class='point'></div>
          </div>
        </div>
        <img src='https://cdn-icons-png.flaticon.com/512/8566/8566237.png'>
        Regresar
      </a>
    </div>
  </div>
  <!-- /////////// Begin Dropdown //////////// -->
  <div class='swanky_wrapper'>
    <input id='Dashboard' name='radio' type='radio'>
    <label for='Dashboard'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/dash.png'>
      <span>Gestionar Usuario</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
      <ul>
        <a href="../usuarios/insertarUsuario.php"><li>Crear Usuario</li></a>
        <a href="../usuarios/listarUsuario.php"><li>Consultar Usuario</li></a>
        <a href="../usuarios/actualizarUsuario.php"> <li>Editar Usuario</li></a>
        <a href="../usuarios/listarUsuario.php"> <li>Eliminar Usuario</li></a>
        </ul>
      </div>
    </label>
    <input id='Sales' name='radio' type='radio'>
    <label for='Sales'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/del.png'>
      <span>Gestionar Ventas</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
      <ul>
          <a href="../ventas/insertarVenta.php"><li>Crear Ventas</li></a>
          <a href="../ventas/listarVenta.php"><li>Consultar Ventas</li></a>
          <a href="../ventas/actualizarVenta.php"><li>Editar Ventas</li></a>
          <a href="../ventas/listarVenta.php"><li>Eliminar Ventas</li></a>
        </ul>
      </div>
    </label>
    <input id='Messages' name='radio' type='radio'>
    <label for='Messages'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/mess.png'>
      <span>Gestionar Productos</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
      <ul>
        <a href="../producto/insertarProducto.php"><li>Crear Productos</li></a>
          <a href="../producto/listarProducto.php"><li>Consultar Productos</li></a>
          <a href="../producto/actualizarProducto.php"><li>Editar Productos</li>
          <a href="../producto/listarProducto.php"><li>Eliminar Productos</li></a>
          
        </ul>
      </div>
    </label>
    <input id='Users' name='radio' type='radio'>
    <label for='Users'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/mess.png'>
      <span>Gestionar Clientes</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
      <ul>
          <li><button style="background-color: #15a3f9; border-style: none;" onclick="window.location='../clientes/insertarCliente.php'">Crear Cliente</button></li> 
          <li><button style="background-color: #15a3f9; border-style: none;" onclick="window.location='../clientes/listarCliente.php'">Consultar Cliente</button></li>
          <li><button style="background-color: #15a3f9; border-style: none;" onclick="window.location='../clientes/actualizarCliente.php'">Editar cliente</button></li>
          <li><button style="background-color: #15a3f9; border-style: none;" onclick="window.location='../clientes/actualizarCliente.php'">Eliminar cliente</button></li>
        </ul>
      </div>
    </label>
    
  </div>
  </div>
  <!-- /////////// End Dropdown //////////// -->
</div>
<!-- / My Footer -->


    
</body>
</html>