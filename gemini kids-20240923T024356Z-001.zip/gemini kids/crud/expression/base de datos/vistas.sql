
create view V_Ventas_por_Cliente as
select C.nombreCliente as cliente, C.telefonoCliente as telefono, C.correoCliente as correo, V.ventaCodigo as ID_Venta, V.fechaVenta as fecha, 
V.cantidadVenta as ventas_realizadas from cliente as C inner join venta as V on C.usua_codigo = V.clie_codigo;

select * from V_Ventas_por_Cliente;


create view V_Productos_Vendidos as
select P.productoCodigo as ID_producto, P.productoNombre as producto, P.precioVenta as precio, V.fechaVenta as fecha, V.cantidadVenta as cantidad 
from producto as P inner join Detalle_Venta as D on P.productoCodigo = D.prod_codigo inner join venta as V on D.vent_codigo = V.ventaCodigo;

select * from V_Productos_Vendidos;


create view V_Factura as
select V.ventaCodigo as ID_Venta, V.fechaVenta as fecha, P.productoNombre as producto, V.cantidadVenta as cantidad, V.ventaTotal as total_productos, 
D.subtotal as precio_total, C.codigoCliente as ID_Cliente, C.nombreCliente as cliente, C.telefonoCliente as teléfono, C.telefonoCliente2 as teléfono_alterno, 
C.direcciónCliente as dirección, C.correoCliente as correo from venta as V inner join Detalle_Venta as D on D.vent_codigo = V.ventaCodigo inner join producto as P
on D.prod_codigo = P.productoCodigo inner join cliente as C on V.clie_codigo = C.codigoCliente;

select * from V_Factura;


create view V_Administrador as
select A.codigoAdministrador as ID_Administrador, A.identificaciónAdministrador as identificación, A.tipodeidentificaciónAdministrador as tipo_de_identificación, A.nombreAdministrador as nombre, 
A.apellidoAdministrador as apellido, A.telefonoAdministrador as teléfono, A.direcciónAdministrador as dirección, C.telefonoCliente2 as teléfono_alterno, C.correoCliente as correo 
from administrador as A inner join usuario as U on A.codigoAdministrador = U.codigo inner join cliente as C on C.codigoCliente = U.codigo;

select * from V_Administrador;


create view V_Historial_de_Ventas as
select V.ventaCodigo as ID_Venta, V.fechaVenta as fecha, P.productoNombre as producto, D.cantidadPorProducto as cantidad, D.subtotal as precio_total 
from producto as P inner join Detalle_Venta as D on P.productoCodigo = D.prod_codigo inner join venta as V on V.ventaCodigo = D.vent_codigo order by V.fechaVenta;

select * from V_Historial_de_Ventas;


create view V_Productos_Realizados as
select D.codigo as ID_Factura, P.productoNombre as producto, D.cantidadPorProducto as cantidad, P.productostock as productos_en_Stock 
from Detalle_Venta as D inner join producto as P on D.prod_codigo = P.productoCodigo; 

select * from V_Productos_Realizados;

