-- -----------------------------------------------------
-- Schema bd_expressiondigital
-- -----------------------------------------------------
drop database if exists script_Base_Datos;

create database script_Base_Datos;
use script_Base_Datos;

create table producto(
productoCodigo int primary key auto_increment not null,
productoDescripción text not null,
productoNombre varchar(50) not null,
precioVenta int not null,
productostock int not null,
productoUnidadMedida varchar(25) not null);

create table Detalle_Venta(
codigo int(11) primary key auto_increment not null,
subtotal int not null,
cantidadPorProducto int not null,
vent_codigo int(11) not null,
prod_codigo int(11) not null);

create table venta(
ventaCodigo int(11) primary key auto_increment not null,
fechaVenta date not null,
cantidadVenta int not null,
ventaTotal int not null,
clie_codigo int(11) not null,
admi_codigo int(11) not null);

create table cliente(
codigoCliente int(11) primary key auto_increment not null,
idCliente varchar(25) not null,
tipodeIdentificaciónCliente varchar(20) not null,
nombreCliente varchar(50) not null,
telefonoCliente varchar(15) not null,
direcciónCliente varchar(50) not null,
telefonoCliente2 varchar(15) not null,
correoCliente varchar(50) not null,
usua_codigo int not null);

create table usuario(
codigo int(11) primary key auto_increment not null,
nombre varchar(32) not null,
clave varchar(30) not null,
tipoUsuario varchar(20) not null);

create table administrador(
codigoAdministrador int(11) primary key not null,
identificaciónAdministrador varchar(20) not null,
tipodeidentificaciónAdministrador varchar(15) not null,
nombreAdministrador varchar(50) not null,
apellidoAdministrador varchar(50) not null,
telefonoAdministrador varchar(20) not null,
direcciónAdministrador varchar(50) not null,
usua_codigo int(11) not null);

alter table Detalle_Venta
add constraint DeVe_Prod
foreign key (prod_codigo)
references producto(productoCodigo) on update cascade;

alter table Detalle_Venta
add constraint DeVe_Venta
foreign key (vent_codigo)
references venta(ventaCodigo) on update cascade;

alter table venta
add constraint Vent_Clie
foreign key (clie_codigo)
references cliente(codigoCliente) on update cascade;

alter table venta
add constraint Vent_Admi
foreign key (admi_codigo)
references administrador(codigoAdministrador) on update cascade;

alter table cliente
add constraint Clie_Usua
foreign key (usua_codigo)
references usuario(codigo) on update cascade on delete cascade;

alter table administrador
add constraint Admi_Usua
foreign key (usua_codigo)
references usuario(codigo) on update cascade on delete cascade;



DELIMITER $$
CREATE PROCEDURE insertarVenta
(
	  _ventaCodigoV INT,
    _fechaVentaV DATE, 
    _cantidadVentaV INT,
    _ventaTotalV INT,
    _admi_codigoV VARCHAR(20),
    _clie_codigoV VARCHAR(25)
)
BEGIN
	INSERT INTO venta VALUES (_ventaCodigoV, _fechaVentaV, _cantidadVentaV, _ventaTotalV,
                               _admi_codigoV,_clie_codigoV);
END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE insertarCliente
(
	  _idCliente varchar(25),
    _tipoIdentificacionCliente varchar(20), 
    _nombreCliente varchar(50),
    _telefonoCliente varchar(15),
    _direccionCliente VARCHAR(50),
    _telefonoCliente2 varchar(15),
    _correoCliente VARCHAR(50)
)
BEGIN
	INSERT INTO venta VALUES (_idCliente, _tipoIdentificacionCliente, _nombreCliente, _telefonoCliente,
                               _direccionCliente,_telefonoCliente2,_correoCliente);
END$$
DELIMITER ;
    


DELIMITER $$
CREATE PROCEDURE listarVenta ()
BEGIN 
      
      SELECT * FROM venta;

END$$
DELIMITER;
-- PROCEDIMIENTO ALMACENADO ACTUALIZAR
DELIMITER $$
CREATE PROCEDURE actualizarVenta(
    _ventaCodigoV INT,
    _fechaVentaV DATE, 
    _cantidadVentaV INT,
    _ventaTotalV INT,
    _admi_codigoV VARCHAR(20),
    _codigoClienteV VARCHAR(25)
)
 BEGIN 

      UPDATE venta SET
      fechaVenta  = _fechaVentaV,
      cantidadVenta = _cantidadVentaV,
      ventaTotal = _ventaTotalV,
      admi_codigo = _admi_codigoV,
      clie_codigo = _clie_codigoV
      WHERE ventaCodigo = _ventaCodigoV;

      END$$

      DELIMITER ;
--CONSULTA X ID
      DELIMITER %%
      CREATE PROCEDURE consultarxId(
          _ventaCodigo INT
      )
      BEGIN

          SELECT * FROM venta
          WHERE ventaCodigo = _ventaCodigo;
      
      END%%

      DELIMITER ;
--ELIMINAR 
 DELIMITER %%
      CREATE PROCEDURE eliminarVenta(
          _ventaCodigo INT
      )
      BEGIN

          DELETE FROM venta
          WHERE ventaCodigo = _ventaCodigo;
      
      END%%

      DELIMITER ;