use script_Base_Datos;


insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Rompecabezas de 200 fichas personalizado hecho a base de láminas de mdf con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.', 'Rompecabezas', 'Personalizada',172000,1);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Torre Eiffel de una altura personalizada hecho a base de lámina de mdf con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.', 'Torre Eiffel', 'Personalizada',77777,1);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Tablero con 32 fichas de ajedrez hecha a base de láminas de mdf con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.','Ajedrez', 'Personalizada',85700,2);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Porta celulares con diseño a base de lámina de mdf con tamaño máximo de 60x90 en una sola pieza.','Porta celulares', 'Personalizada',56000,1);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Luna decorativa hecha a base de lámina de mdf con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.','Luna MDF', 'Personalizada',9500,3);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Árbol Decorativo a base de lámina de mdf con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.','Árbol MDF', 'Personalizada',300000,1);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Joyeros a base de láminas de mdf con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.','Joyeros Decorados/ sin decorar', 'Personalizada',37000,3);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Figura de animal a base de láminas de mdf con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.','Figura de animal', 'Personalizada',68000,1);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Dinosaurio a base de láminas con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.','Dinosaurio', 'Personalizada',82000,2);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Portaretratos a base de láminas con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.','Portaretratos', 'Personalizada',99999,1);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Damas Chinas a base de láminas con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.','Damas Chinas', 'Personalizada',66000,1);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Nombre Decorativo al gusto del cliente; a base de láminas con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.','Nombre Decorativo', 'Personalizada',35000,1);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Cajitas a base de láminas MDF con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.','Cajitas', 'Personalizada',48000,4);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Aretes a base de láminas MDF con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.','Aretes', 'Personalizada',8000,5);
insert into producto (productoDescripción, productoNombre, productoUnidadMedida, precioVenta, productoStock)
values ('Alcancia a base de láminas MDF con tamaño máximo de 60x90 en una sola pieza, 
si el cliente desea un tamaño más grande, se hacen las piezas por separado y se ensamblan.','Alcancia', 'Personalizada',13000,2);

select * from producto;



insert into usuario (nombre, clave, tipoUsuario) values 
('Santiago Rivas','SanRiv13','Cliente'), 
('Mateo Duarte','MatDua13','Cliente'),
('Daniel Perez','DanPer13','Cliente'),
('Pablo Contreras','PabCon13','Cliente'),
('Álvaro Herrera','AlvHer13','Cliente'),
('Adrián Agreste','AdrAgr13','Cliente'),
('David Lopez','DavLop13','Cliente'),
('Diego Gomez','DieGom13','Cliente'),
('Javier Herrera','JavHer13','Cliente'),
('Sergio Rodriguez','SerRod13','Cliente'),
('Manuel Díaz','ManDia13','Cliente'),
('Martín Morales','MarMor13','Cliente'),
('Carlos Suluaga','CarSul13','Cliente'),
('Lucas Prieto','LucPri13','Cliente'),
('Jorge Cardona','JorCar13','Administrador');

select * from usuario;



insert into cliente (idCliente, tipodeidentificaciónCliente, nombreCliente, telefonoCliente, direcciónCliente, telefonoCliente2, correoCliente, usua_codigo) values 
('51780556','CC','Santiago Rivas','3124565161','Cll 8B Sur #2 - 33 Este','3125384544','santiagoriv599@gmail.com',1),
('54067436','CC','Mateo Duarte','3126569574','Cra 3A Este #14-2 Sur','3114564369','mateodurmiendo@gmail.com',2),
('41423523','CC','Daniel Perez','3214563765','Cl. 129b Bis #90a-19 a 90a-1','3214985473','danipendejo482@gmail.com',3),
('43906344','CC','Pablo Contreras','3155438963','Calle 54a Sur #127a57','3124387436','contreras4658@hotmail.com',4),
('65039475','CC','Álvaro Herrera','3134996854','Cl. 4a Bis #23a-25','3134846645','herreriadonjuan@gmail.com',5),
('76563776','CC','Adrián Agreste','3123543498','Calle 21 Sur #11','3144968745','agrestadri07@hotmail.com',6),
('99222587','CC','David Lopez','3134736287','3 Este85 Cl. 31 Sur','3316704932','davidcito64@gmail.com',7),
('12436578','CC','Diego Gomez','3149744520','3217 Cl. 44 Sur','3206933527','diegventas01@gmail.com',8),
('32798098','CC','Javier Herrera','3116768946','44 Sur43 Cra. 32','3214968384','javierdogs@gmail.com',9),
('56934876','CC','Sergio Rodriguez','3167459001','27 Sur78 Cra. 5','4354356','adomiciliosssergio@gmail.com',10),
('12312312','CC','Manuel Díaz','3216470856','1681 Cra. 21','5784507','manu.facturas@gmail.com',11),
('78320325','CC','Martín Morales','3475539040','Tv. 76 #13640','3134278905','martymoras@gmail.com',12),
('57483685','CC','Carlos Suluaga','3689367211','Cra. 60a #9050','367089326','c4rl0s3498@gmail.com',13),
('53454366','CC','Lucas Prieto','3275649876','104b48 Cl. 22f','3275649876','quiensabe285@gmail.com',14),
('4248741','CC','Jorge Enrique','3057104247','Cra 25 A bis #5A-48','3004303330','expression.digital@gmail.com',15);

select * from cliente;





insert into administrador values (1,'4248741','CC', 'Jorge Enrique','Cardona Carabuena','3057104247','Cra 25 A bis #5A-48',15);

select * from administrador;




insert into venta (admi_codigo, fechaVenta, cantidadVenta, 
ventaTotal, clie_codigo) values 
(1,'2008/05/21',1,1,1),
(1,'2005/09/24',1,1,2),
(1,'2006/07/06',2,2,3),
(1,'2002/11/04',1,1,4),
(1,'2004/09/11',3,3,5),
(1,'2000/01/01',1,1,6),
(1,'2001/02/01',2,2,7),
(1,'1999/01/12',1,1,8),
(1,'2003/11/16',2,2,9),
(1,'2003/12/01',1,1,10),
(1,'2004/01/12',1,1,11),
(1,'2019/07/25',1,1,12),
(1,'2020/05/25',4,4,13),
(1,'2020/06/01',5,5,14),
(1,'2021/05/11',2,2,15);

select * from venta;





insert into Detalle_Venta (vent_codigo, prod_codigo, 
subtotal, cantidadPorProducto) values 
(1,1,172000,1),
(2,2,77777,1),
(3,3,171400,2),
(4,4,56000,1),
(5,5,28500,3),
(6,6,181000,1),
(7,7,111000,2),
(8,8,68000,1),
(9,9,164000,2),
(10,10, 99999,1),
(11,11, 66000,1),
(12,12, 35000,1),
(13,13, 192000,4),
(14,14, 40000,5),
(15,15, 26000,2);

select * from Detalle_Venta;

