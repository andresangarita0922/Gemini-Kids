<?php

include('../modelos/modelosUsuario.php'); 

if(isset($_POST['usuario']) && !empty($_POST['usuario'])){
    $usuarioIN = $_POST['usuario']; 
    $claveUsuarioIN = $_POST['clave']; 

    try {
        
        $objUsuario = new modelosUsuario(NULL, $usuarioIN, NULL, NULL); 
        $Consulta = $objUsuario->consultaLogin(); 
        
        $usuarioBD = $Consulta->nombre; 
        $claveUsuarioBD = $Consulta->clave; 
        $tipoBD = $Consulta->tipoUsuario; 

        echo($usuarioBD.$claveUsuarioBD.$tipoBD);

        if($usuarioIN == $usuarioBD)
        {
            if($claveUsuarioIN == $claveUsuarioBD)
            {
                session_start();
                $_SESSION['usuario'] = $tipoBD; 
                
                if($tipoBD == "Cliente"){
                    echo '<script type="text/javascript">
                            alert("INGRESO EXITOSO, BIENVENIDO CLIENTE!!");    
                            window.location.href="../vistas/menu/menuCliente.php"; 
                        </script>';
                }
                elseif ( $tipoBD == "Administrador"){
                    echo '<script type="text/javascript">
                            alert("INGRESO EXITOSO, BIENVENIDO ADMIN!!");    
                            window.location.href="../vistas/menu/menuPrincipal.php"; 
                        </script>';
                }
            }
            else{
               echo '<script type="text/javascript">
                 alert("ERROR EN LA CONTRASEÑA");    
                 window.location.href="../index.php"; 
                </script>';
            }
        }
        else{
            echo '<script type="text/javascript">
                   alert("ERROR EN EL USUARIO");    
                   window.location.href="../php/register.php"; 
               </script>'; 
        }


    } catch (\Throwable $error) {
        echo("ERROR (controlador): ".$error.getMessage());
        die();
    }
}

?>