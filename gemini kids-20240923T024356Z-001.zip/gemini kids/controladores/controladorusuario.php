<?php

include($_SERVER['DOCUMENT_ROOT'].'/gemini/modelos/modelosUsuario.php');


if(isset($_POST['codigo']) && !empty($_POST['codigo'])){

    #ATRAPAR DATOS DESDE LA VISTA
    $codigo =  $_POST['codigo'];
    $nombre = $_POST['nombre'];
    $clave = $_POST['clave'];
    $tipoUsuario= $_POST['tipoUsuario'];
    
    echo($tipoUsuario);
    $objUsuario = new modelosUsuario($codigo, $nombre, $clave, $tipoUsuario);
     
    $objUsuario->registrarUsuario();

    echo '<script type="text/javascript">
    alert("USUARIO REGISTRADO CORRECTAMENTE!!");
    window.location.href="../vistas/usuarios/insertarUsuario.php";
    </script>';

}

//ACTUALIZAR
if(isset($_POST["codigoA"]) && !empty($_POST["codigoA"])) {
    
    $codigo = $_POST["codigoA"];
    
    $nombre = $_POST["nombreA"];
    
    $clave = $_POST["claveA"];

    $tipoUsuario= $_POST["tipoUsuarioA"];
    
   
    
    $objUsuario = new modelosUsuario($codigo, $nombre, $clave, $tipoUsuario);
    
    $objUsuario->actualizarUsuario();
    
    echo '<script type="text/javascript">
    
    alert("USUARIO ACTUALIZADO CORRECTAMENTE!!");
        
    window.location.href="../vistas/usuarios/listarUsuario.php"; </script> ';
}

//listar producto
function consultarUsuario(){
    $objUsuario=new modelosUsuario(null,null,null,null);
    $consultaUsuario=$objUsuario->listarUsuario();
    return $consultaUsuario;
}

//consultar producto id
function consultaUsuario($codigo){
    $objUsuario= new modelosUsuario($codigo,NULL,NULL,NULL);
    $consultaUsuario= $objUsuario->consultarUsuario();
    return $consultaUsuario;
}
//ELIMINAR
if(isset($_GET["codigoE"]) && !empty($_GET["codigoE"])) {

    $codigo = $_GET["codigoE"];
    
    $objUsuario = new modelosUsuario ($codigo, NULL, NULL, NULL);
    
    $objUsuario->eliminarUsuario();

    echo '<script type="text/javascript">
        alert("USUARIO ELIMINADO CORRECTAMENTE!!!!");
        window.location.href="../vistas/usuarios/listarUsuario.php";
    </script> ';
    
    
}