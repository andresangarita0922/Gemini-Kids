<?php
include($_SERVER['DOCUMENT_ROOT'].'/gemini/modelos/modeloVenta.php');
if(isset($_POST["ventaCodigo"]) && !empty ($_POST["ventaCodigo"])){
    $ventaCodigoV = $_POST["ventaCodigo"];
    $fechaVentaV = $_POST["fechaVenta"];
    $cantidadVentaV = $_POST["cantidadVenta"];
    $ventaTotalV = $_POST["ventaTotal"];
    $codigoVendedorV = $_POST["codigoVendedor"];
    $codigoClienteV = $_POST["codigoCliente"];

    echo $ventaCodigoV;

    $ventaCodigo = new modeloVenta ($ventaCodigoV, $fechaVentaV, $cantidadVentaV, $ventaTotalV,
                                    $codigoVendedorV, $codigoClienteV);
    $ventaCodigo->insertarVenta();

    echo '<script type="text/javascript">
                alert("VENTA REGISTRADA CORRECTAMENTE!!!!");
                window.location.href="../vistas/ventas/insertarVenta.php";
                </script> ';

                
}
//LISTAR VENTA
function consultarVenta(){
    $objVenta=new modeloventa(NULL, NULL,NULL, NULL, NULL,NULL);
    $consultaVenta=$objVenta->consultarVenta();
    return $consultaVenta;
}


//ACTUALIZAR
if(isset($_POST["codigoVentaA"]) && !empty($_POST["codigoVentaA"])) {
    
    $ventaCodigo = $_POST["codigoVentaA"];
    
    $fechaVenta = $_POST["fechaVentaA"];
    
    $cantidadVenta = $_POST["cantidadVentaA"];

    $ventaTotal = $_POST["ventaTotalA"];
    
    $codigoVendedor = $_POST["codigoVendedorA"];
    
    $codigoCliente = $_POST["codigoClienteA"];
    
    $objVenta = new modeloVenta($ventaCodigo, $fechaVenta, $cantidadVenta, $ventaTotal, $codigoVendedor, $codigoCliente);
    
    $objVenta->actualizarVenta();
    
    echo '<script type="text/javascript">
    
    alert("VENTA ACTUALIZADA CORRECTAMENTE!!");
        
    window.location.href="../vistas/ventas/listarVenta.php"; </script> ';

    

}

//CONSULTAR PRODUCTO x ID
function ventaConsultarXid($ventaCodigo){
    $objVenta= new modeloVenta($ventaCodigo,NULL,NULL,NULL,NULL,NULL);
    $consultarVenta= $objVenta->consultarVentaxID();
    return $consultarVenta;
}
//ELIMINAR
if(isset($_GET["ventaCodigoE"]) && !empty($_GET["ventaCodigoE"])) {

    $ventaCodigo = $_GET["ventaCodigoE"];
    
    $objVenta = new modeloVenta ($ventaCodigo, NULL, NULL, NULL, NULL, NULL);
    
    $objVenta->eliminarVenta();
    
    echo '<script type="text/javascript">
    alert("VENTA ELIMINADA CORRECTAMENTE!!!!");
    window.location.href="../vistas/ventas/listarVenta.php";
</script> ';
}

?>