<?php

session_start();

if (file_exists('../modelos/modelosUsuario.php')){
    require_once('../modelos/modelosUsuario.php');
}

if(isset($_POST['usuario']) && isset($_POST['clave'])){
    $usuario = $_POST['usuario']; 
    $clave = $_POST['clave']; 

    // Incluir la clase de modelosUsuario
    include('../modelos/modelosUsuario.php');

    // Crear una instancia de modelosUsuario
    $objUsuario = new modelosUsuario(null, $usuario, null, null);

    // Realizar la consulta de autenticación
    $consulta = $objUsuario->consultaLogin();

    if ($consulta && password_verify($clave, $consulta->clave)) {
        // Las credenciales son válidas
        $_SESSION['usuario'] = $consulta->tipoUsuario;

        // Redirigir al usuario después de iniciar sesión
        if ($consulta->tipoUsuario == "cliente") {
            header('Location: ../vistas/menu/menuCliente.php');
            exit();
        } elseif ($consulta->tipoUsuario == "administrador") {
            header('Location: ../vistas/menu/menuAdministrador.php');
            exit();
        }
    } else {
               echo '<script type="text/javascript">
                 alert("ERROR EN EL USUARIO O LA CONTRASEÑA");    
                 window.location.href="../index.html"; 
                </script>';
            }
        } else {
            echo '<script type="text/javascript">
                   alert("BIVENIDO USUARIO");    
                   window.location.href="../index.html"; 
               </script>'; 
   
    }

?>