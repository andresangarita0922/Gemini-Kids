<?php

include($_SERVER['DOCUMENT_ROOT'].'/gemini/modelos/modeloProducto.php');


if(isset($_POST['nombreProducto']) && !empty($_POST['nombreProducto'])){

    #ATRAPAR DATOS DESDE LA VISTA
    $productoNombre =  $_POST['nombreProducto'];
    $productoPrecioVenta = $_POST['precioProducto'];
    $productoUnidadMedida = $_POST['medidaProducto'];
    $productostock= $_POST['stockProducto'];
    $productoDescripcion = $_POST['descripcionProducto'];

    $objProducto = new modeloProducto(NULL, $productoNombre, $productoPrecioVenta, $productoUnidadMedida, $productostock, $productoDescripcion);
     
    $objProducto->registrarProducto();

    echo '<script type="text/javascript">
    alert("PRODUCTO REGISTRADO CORRECTAMENTE!!");
    window.location.href="../vistas/producto/insertarProducto.php";
    </script>';

}

//ACTUALIZAR
if(isset($_POST["productoCodigoA"]) && !empty($_POST["productoCodigoA"])) {
    
    $productoCodigo = $_POST["productoCodigoA"];
    
    $productoNombre = $_POST["productoNombreA"];
    
    $productoPrecioVenta = $_POST["productoPrecioA"];

    $productoUnidadMedida = $_POST["productoMedidaA"];
    
    $productostock = $_POST["productoStockA"];
    
    $productoDescripcion = $_POST["productoDescripcionA"];
    
    $objProducto = new modeloProducto($productoCodigo, $productoNombre, $productoPrecioVenta, $productoUnidadMedida, $productostock, $productoDescripcion);
    
    $objProducto->actualizarProducto();
    
    echo '<script type="text/javascript">
    
    alert("PRODUCTO ACTUALIZADO CORRECTAMENTE!!");
        
    window.location.href="../vistas/producto/listarProducto.php"; </script> ';
}

//listar producto
function consultarProducto(){
    $objProducto=new modeloProducto(null,null,null,null,null,null);
    $consultaProducto=$objProducto->listarProducto();
    return $consultaProducto;
}

//consultar producto id
function productoConsultar($productoCodigo){
    $objProducto= new modeloProducto($productoCodigo,NULL,NULL,NULL,NULL,NULL);
    $consultaProducto= $objProducto->consultarProducto();
    return $consultaProducto;
}
//ELIMINAR
if(isset($_GET["codigoProductoE"]) && !empty($_GET["codigoProductoE"])) {

    $productoCodigo = $_GET["codigoProductoE"];
    
    $objProducto = new modeloProducto ($productoCodigo, NULL, NULL, NULL, NULL, NULL);
    
    $objProducto->eliminarProducto();
    
    echo '<script type="text/javascript">
    alert("PRODUCTO ELIMINADO CORRECTAMENTE!!!!");
    window.location.href="../vistas/producto/listarProducto.php";
</script> ';
}









?>

