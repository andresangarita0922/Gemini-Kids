<?php

include($_SERVER['DOCUMENT_ROOT'].'/gemini/modelos/modeloCliente.php');


if(isset($_POST['idCliente']) && !empty($_POST['idCliente'])){

    #ATRAPAR DATOS DESDE LA VISTA
    $idCliente=  $_POST['idCliente'];
    $tipoIdentificacionCliente = $_POST['tipoIdentificacionCliente'];
    $nombreCliente= $_POST['nombreCliente'];
    $telefonoCliente= $_POST['telefonoCliente'];
    $direccionCliente= $_POST['direccionCliente'];
    $telefonoCliente2= $_POST['telefonoCliente2'];
    $correoCliente= $_POST['correoCliente'];


    $objclientes = new modeloCliente( $idCliente, $tipoIdentificacionCliente, $nombreCliente, $telefonoCliente, $direccionCliente,$telefonoCliente2,$correoCliente);
     
    $objclientes->insertarCliente();

    echo '<script type="text/javascript">
    alert("CLIENTE REGISTRADO CORRECTAMENTE!!");
    window.location.href="../vistas/clientes/insertarCliente.php";
    </script>';

}

//ACTUALIZAR
if(isset($_POST["idClienteA"]) && !empty($_POST["idClienteA"])) {
    
    
    
    $idCliente = $_POST["idClienteA"];
    
    $tipoIdentificacionCliente = $_POST["tipoIdentificacionClienteA"];

    $nombreCliente = $_POST["nombreClienteA"];
    
    $telefonoCliente = $_POST["telefonoClienteA"];
    
    $direccionCliente = $_POST["direccionClienteA"];

    $telefonoCliente2 = $_POST["telefonoCliente2A"];

    $correoCliente = $_POST["correoClienteA"];
    
    $objclientes = new modeloCliente($idCliente, $tipoIdentificacionCliente, $nombreCliente, $telefonoCliente, $direccionCliente,$telefonoCliente2,$correoCliente);
    
    $objclientes->actualizarCliente();
    
    echo '<script type="text/javascript">
    
    alert("CLIENTE ACTUALIZADO CORRECTAMENTE!!");
        
    window.location.href="../vistas/clientes/listarCliente.php"; </script> ';
}

//LISTAR CLIENTE
function consultarClientes(){
    $objclientes=new modeloCliente(null,null,null,null,null,null,null);
    $consultaClientes=$objclientes->listarCliente();
    return $consultaClientes;
}




//ELIMINAR
if(isset($_GET["idClienteE"]) && !empty($_GET["idClienteE"])) {

    $idCliente = $_GET["idClienteE"];
    
    $objclientes = new modeloCliente ($idCliente, NULL, NULL, NULL, NULL, NULL,NULL);
    
    $objclientes->eliminarCliente();

    echo '<script type="text/javascript">
    alert("cliente ELIMINADO CORRECTAMENTE!!!!");
    window.location.href="../vistas/clientes/listarCliente.php";
</script> ';
    
 
}



?>