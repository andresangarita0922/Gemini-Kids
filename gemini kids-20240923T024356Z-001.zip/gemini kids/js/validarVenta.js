function validarVenta(){
     var ventaCodigo;
     var fechaVenta;
     var cantidadVenta;
     var ventaTotal;
     var codigoVendedor;
     var codigoCliente;

     ventaCodigo = document.getElementById("ventaCodigo").value;
     codigoVendedor = document.getElementById("codigoVendedor").value;
     codigoCliente = document.getElementById("codigoCliente").value;
     
}

    //VALIDAR CAMPOS VACIOS DEL FORMULARIO
    if (ventaCodigo === "" || fechaVenta === "" || ventaTotal === "" ||codigoVendedor === "" || codigoCliente === "")
    {
        alert("Ningun campo de este formulario puede estar vacio");
        return false;
    }

    //VALIDAR LONGITUD DE CARACTERES
    var numeroCaracteres = rhVenta.lengt;
    if (numeroCaracteres === 4)
    {
        alert("El campo venta Codigo solo admite 4 caracteres");
        return false;
    }
    if (codigoVendedor.lengt >= 6)
    {
        alert("El campo Codigo del Vendedor debe tener maximo 6 numeros");
        return false;
    }
    if (codigoCliente.lengt >= 6)
    {
        alert("El campo Codigo del Cliente debe tener maximo 6 numeros");
        return false;
    }
    //VALIDAR CAMPOS NUMERICOS
    if (isNaN(ventaCodigo))
    {
        alert("El codigo de la Venta solo debe contener numeros");
        return false;
    }
    if (isNaN(codigoVendedor))
    {
        alert("El codigo del Vendedor solo debe contener numeros");
        return false;
    }
    if (isNaN(codigoCliente))
    {
        alert("El codigo del Cliente solo debe contener numeros");
        return false;
    }