function validarCliente(){
    //CREAR LAS VARIABLES   
    var docCliente; 
    var nomCliente; 
    var telCliente1; 
    var telCliente2; 
    var direCliente; 
    var corrCliente; 

    //CAPTURAR DATOS DESDE LOS INPUT A LAS VARIABLES CON EL ID
    docCliente = document.getElementById("docCliente").value; 
    nomCliente = document.getElementById("nomCliente").value; 
    telCliente1 = document.getElementById("telefono1").value; 
    telCliente2 = document.getElementById("telefono2").value; 
    direCliente = document.getElementById("direCliente").value; 
    corrCliente = document.getElementById("corrCliente").value; 

    //VALIDA CAMPOS VACIOS
    if(docCliente === "" || nomCliente ==="" || telCliente1 === "" || telCliente2==="" || direCliente ==="" || corrCliente === ""){
        alert("Error, No pueden existir campos vacios");
        return false; 
    }

    //VALIDA NUMERICOS 
    if(isNaN(docCliente)){
        alert("Error, El documento no puede ser alfabetico"); 
        return false; 
    }
    if(isNaN(telCliente1)){
        alert("Error, El telefono no puede ser alfabetico"); 
        return false;
    }

    //VALIDAR LONGITUD DE CARACTERES 
    var numLetras = direCliente.length; 
    if(numLetras > 10){
        alert("Error, El numero de letras en la direccion es mayor a 10"); 
        return false;
    }
    if(telCliente1.length !== 10){
        alert("Error, El numero celular es incorrecto"); 
        return false;
    }

    //VALIDAR DATOS DE TEXTO 
    if(!isNaN(nomCliente)){
        alert("Error, El nombre no es numerico"); 
        return false;
    }
    var numeros = /[0-9]/g; 
    if(numeros.test(nomCliente)){
        alert("Error, El nombre no puede contener numeros"); 
        return false;
    }

    //VALIDACION DE CORREO ELECTRONICO
    //CREAR UNA EXPRESION REGULAR 

    var expCorreo = /\w+@+\w+\.+\w/; 
    if(!expCorreo.test(corrCliente)){
        alert("Error, Correo incorrecto"); 
        return false;
    }
}