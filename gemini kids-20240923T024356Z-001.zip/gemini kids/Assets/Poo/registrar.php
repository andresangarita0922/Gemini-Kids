<?php
$filter_name= filter_var($_post['name'], filter_sanitize_string);
$name = mysqli_real_escape_string($conn, $fliter_name);

$filter_email = filter_var($_post[email], filter_sanitize_string);
$email = mysqli_real_escape_string($conn, $filter_email);

$filter_password = filter_var($_post['password'], filter_sanitize_string);
$cpassword = mysqli_real_escape_string($conn, $filter_cpassword);
$select_user =mysqli_query($conn, "select * from 'users where email = '$email") or die ('query failed'); 

if (mysqli_num_rows($select_user)>0){
    $message[] = 'usuario existente';
}
else{
    if($password 1= $cpassword){
        $message[] = 'contraseña incorrecta';
    }
    else{
         mysqli_query(&conn, "insert into 'users' ('name','email','password')values ('$name' , '$email',
         'password'¨)") or die ('query failed');
$message[] = registrado correctamente';
header('location_login.php');
    }
}
?>