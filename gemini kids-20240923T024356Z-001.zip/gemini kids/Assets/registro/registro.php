<?php
//validamos datos del servicio
$user="root";
$pass='proyecto04';
$host="localhost"

//contetamos el base de datos 
$connection = mysquli_connect ($host,$user,$pass);

//hacemos llamado al imput de formato 
$nombre =$_POST ["nombre"];
$email= $_POST["apellido"];
$contraseña= $_POST["celular"];

if(!$connection)
{
    echo "no se ha podido conectar con el servidor" .mysql_error()
}
else
{
    echo "<b><h3>Hemos conectado al servidor</h3></b>"
}
//indicamos el nombre de la base datos 
$datab="formulario";
//indicaamos seleccionar ala base datos
$db =mysqli_select_db($connection,$datab);

if(!$db)
{
    echo "no se ha podido encontrar la tabla";
}
else
{
    echo "<h3>tabla seleccionada:</h3>"
}

$instruccion_sql="insert into tabla (nombre,apellido,celular)
        values('$nombre','$apellido','$celular')";

$resultado =mysqli_query($connection,$instruccion_sql);

$consulta="select = from tabla";

$resulta =mysqli_query($connection,$consulta);
if(!$result)
{
    echo "no se ha podido realizar la consulta";
}
echo "<table>";
echo "<tr>";
echo "<th><h1>id</th></h1>";
echo "<th><h1>nombre</th></h1>";
echo "<th><h1>email</th></h1>";
echo "<th><h1>contraseña</th><h1>";
echo "</tr>";

while ($colum =mysqli_fetch_array($result))
{
    echo "<tr>";
    echo "<td><h2>" . $colum['id']."</td></h2>";
    echo "<td><h2>" . $colum ['nombre']."</td></h2>";
    echo "<td><h2>" . $colum ['apellido'] ."</td></h2>";
    echo "<td><h2>" . $colum ['celular'] ."</td></h2>";
    echo "</tr>";
}
echo "</table>";
mysqli_close( $connection );










