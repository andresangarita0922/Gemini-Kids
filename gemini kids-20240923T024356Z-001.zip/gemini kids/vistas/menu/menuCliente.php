<?php

session_start(); 

if($_SESSION['usuario']==NULL || $_SESSION['usuario']==""){
    session_destroy(); 
    header("location: ../../index.html");
}
elseif($_SESSION['usuario']=="administrador"){
    session_destroy(); 
    header("location: ../../index.html");
} 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../assets/css/menu.css">
    <title>MENU CLIENTE</title>
</head>
<body>
    <!-- / My brand -->
<div class='brand'>
  <a href='https://linktr.ee/geminikids' target='_blank'>
    
  </a>
</div>
<!-- / Begin Body -->
<div class='swanky'>
  <!-- / Introduction Block -->
  <div class='swanky_title'>
    <h1>CONOCE NUESTRO MENU</h1>
    <p>Aprende mas sobre nosotros.</p>
    
    </div>
    <div class='swanky_title__social'>
    <a href='../../controladores/controladorCerrarSesion.php'>
        <div class=''>
          <div class='arrow'>
            <div class='stem'></div>
            <div class='point'></div>
          </div>
        </div>
        <img src='https://cdn-icons-png.flaticon.com/512/8566/8566237.png'>
        Regresar
      </a>
    </div>
  </div>
  <!-- /////////// Begin Dropdown //////////// -->
  <div class='swanky_wrapper'>
    <input id='Dashboard' name='radio' type='radio'>
    <label for='Dashboard'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/dash.png'>
      <span>Gestionar Usuario</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
        <ul>
          <li>Registrar usuario propio</li>
          <li>Modificar usuario propio</li>
          <li>Inactivar usuario propio</li>
        </ul>
      </div>
    </label>
    <input id='Sales' name='radio' type='radio'>
    <label for='Sales'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/del.png'>
      <span>Gestionar Ventas</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
        <ul>
          <li>Registrar venta</li>
          <li>Consultar historial venta</li>
          
        </ul>
      </div>
    </label>
    <input id='Messages' name='radio' type='radio'>
    <label for='Messages'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/mess.png'>
      <span>Gestionar Productos</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
        <ul>
          <li>Consultar productos</li>
          
        </ul>
      </div>
    </label>
    <input id='Users' name='radio' type='radio'>
    <label for='Users'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/users.png'>
      <span>Gestionar Cliente</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
        <ul>
          <li>Consultar datos propios</li>
          <li>Modificar datos propios</li>
          
  </div>
  <!-- /////////// End Dropdown //////////// -->
</div>
<!-- / My Footer -->


    
</body>
</html>