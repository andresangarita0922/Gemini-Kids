<?php

require_once '../../assets/dompdf/autoload.inc.php';
use Dompdf\Dompdf;

ob_start();
require 'reporte.php';
$html = ob_get_clean();

$domPdf =new Dompdf();

$opciones = $domPdf -> getOptions();
$opciones->set(array('isRemoteEnabled'=>true));
$domPdf-> setPaper('letter');

$domPdf->loadHtml($html);
$domPdf->setPaper('letter');

$domPdf->render();
$domPdf->stream("factura.pdf",array("Attachment"=>false));


?>