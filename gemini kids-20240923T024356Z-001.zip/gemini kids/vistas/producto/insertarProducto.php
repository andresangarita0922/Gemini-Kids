<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../assets/css/menu.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <title>MENU</title>
</head>
<body>
    <!-- / My brand -->
    <div class='brand'>
  <a href='https://www.jamiecoulter.co.uk' target='_blank'>
    <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/logo.png'>
  </a>
</div>
<!-- / Begin Body -->
<div class='swanky'>
  <!-- / Introduction Block -->
  <div class='swanky_title'>
    <h1>Crear Producto</h1>
    <br>
        <form action="../../controladores/controladorProducto.php" method="post">
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Nombre Producto</span>
                <input type="text" class="form-control" placeholder="Producto" aria-label="Producto" aria-describedby="basic-addon1" name="nombreProducto" required>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Precio Producto</span>
                <input type="number" class="form-control" placeholder="Precio" aria-label="Precio" aria-describedby="basic-addon1" name="precioProducto"required>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Medida Producto</span>
                <input type="text" class="form-control" placeholder="Medida" aria-label="Medida" aria-describedby="basic-addon1" name="medidaProducto"required>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Existencias Producto</span>
                <input type="number" class="form-control" placeholder="Existencias" aria-label="Existencias" aria-describedby="basic-addon1" name="stockProducto"required>
            </div>
            <div class="input-group">
                <span class="input-group-text">Descripcion</span>
                <textarea class="form-control" aria-label="With textarea" name="descripcionProducto"required></textarea>
            </div>
            <div class='swanky_title__social'>
    <a href='../menu/menuPrincipal.php'>
        <div class=''>
          <div class='arrow'>
            <div class='stem'></div>
            <div class='point'></div>
          </div>
        </div>
        <img src='https://cdn-icons-png.flaticon.com/512/6927/6927593.png'>
           Menu
      </a>
    </div>
    <div class='swanky_title__social'>
    <a href='../../controladores/controladorCerrarSesion.php'>
        <div class=''>
          <div class='arrow'>
            <div class='stem'></div>
            <div class='point'></div>
          </div>
    </div>
    <img src='https://cdn-icons-png.flaticon.com/512/8566/8566237.png'>
        Regresar
      </a>
    </div>
    <br>
            <input type="submit" class="btn btn-dark" value="Guardar Venta" >
  </div>
            

        </form>
        

    
 
  <!-- /////////// Begin Dropdown //////////// -->
  <div class='swanky_wrapper'>
    <input id='Dashboard' name='radio' type='radio'>
    <label for='Dashboard'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/dash.png'>
      <span>Gestionar Usuario</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
      <ul>
        <a href="../usuarios/insertarUsuario.php"><li>Crear Usuario</li></a>
        <a href="../usuarios/listarUsuario.php"><li>Consultar Usuario</li></a>
        <a href="../usuarios/actualizarUsuario.php"> <li>Editar Usuario</li></a>
        <a href="../usuarios/listarUsuario.php"> <li>Eliminar Usuario</li></a>
        </ul>
      </div>
    </label>
    <input id='Sales' name='radio' type='radio'>
    <label for='Sales'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/del.png'>
      <span>Gestionar Ventas</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
      <ul>
          <a href="../ventas/insertarVenta.php"><li>Crear Ventas</li></a>
          <a href="../ventas/listarVenta.php"><li>Consultar Ventas</li></a>
          <a href="../ventas/actualizarVenta.php"><li>Editar Ventas</li></a>
          <a href="../ventas/listarVenta.php"><li>Eliminar Ventas</li></a>
        </ul>
      </div>
    </label>
    <input id='Messages' name='radio' type='radio'>
    <label for='Messages'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/mess.png'>
      <span>Gestionar Productos</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
      <ul>
        <a href="../producto/insertarProducto.php"><li>Crear Productos</li></a>
          <a href="../producto/listarProducto.php"><li>Consultar Productos</li></a>
          <a href="../producto/actualizarProducto.php"><li>Editar Productos</li><li>Editar Productos</li>
          <a href="../producto/listarProducto.php"><li>Eliminar Productos</li></a>
          
        </ul>
      </div>
    </label>
    <input id='Users' name='radio' type='radio'>
    <label for='Users'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/mess.png'>
      <span>Gestionar Clientes</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
      <ul>
          <li><button style="background-color: #15a3f9; border-style: none;" onclick="window.location='../clientes/insertarCliente.php'">Crear Cliente</button></li> 
          <li><button style="background-color: #15a3f9; border-style: none;" onclick="window.location='../clientes/listarCliente.php'">Consultar Cliente</button></li>
          <li><button style="background-color: #15a3f9; border-style: none;" onclick="window.location='../clientes/actualizarCliente.php'">Editar cliente</button></li>
          <li><button style="background-color: #15a3f9; border-style: none;" onclick="window.location='../clientes/actualizarCliente.php'">Eliminar cliente</button></li>
        </ul>
      </div>
    </label>
    
  </div>
  </div>

  <!-- /////////// End Dropdown //////////// -->
</div>
<!-- / My Footer -->
<div class='love'>
  
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

    
</body>
</html>