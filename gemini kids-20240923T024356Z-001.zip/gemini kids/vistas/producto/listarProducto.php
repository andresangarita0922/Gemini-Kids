<?php 

include('../../controladores/controladorProducto.php');

session_start(); 

if($_SESSION['usuario']==NULL || $_SESSION['usuario']==""){
    session_destroy(); 
    header("location: ../../index.html");
}
elseif($_SESSION['usuario']=="cliente"){
    session_destroy(); 
    header("location: ../../index.html");
}

else {
  $listarProducto=consultarProducto();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../assets/css/menu.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <title>MENU ADMINISTRADOR</title>
</head>
<body>
    <!-- / My brand -->
<div class='brand'>
  <a href='https://www.jamiecoulter.co.uk' target='_blank'>
    
  </a>
</div>
<!-- / Begin Body -->
<div class='swanky'>
  <!-- / Introduction Block -->
  <div class='swanky_title'>
    <div>
    <h1>Productos</h1>
    <div class="demo">
  <form class="form-search">
    <div class="input-group">
      <input class="form-control form-text" maxlength="128" placeholder="..." size="15" type="text" />
      <span class="input-group-btn"><button class="btn btn-primary"><i class="fa fa-search fa-lg">buscar🔍</i></button></span>
    </div>
  </form>
</div>
<br>
    <table class="table table-success table-striped">
        <thead>
            <tr>
            <th scope="col">Codigo</th>
            <th scope="col">Nombre</th>
            <th scope="col">PrecioVenta</th>
            <th scope="col">Unidad Medida</th>
            <th scope="col">Stock</th>
            <th scope="col">Descripcion</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($listarProducto as $filaProducto): ?>
        <tr>
            <th scope="row"><?php echo ($filaProducto->productoCodigo);?></th>
            <td><?php echo ($filaProducto->productoNombre); ?></td>
            <td><?php echo($filaProducto->productoPrecioVenta); ?></td>
            <td><?php echo($filaProducto->productoUnidadMedida); ?></td>
            <td><?php echo($filaProducto->productostock);?></td>
            <td><?php echo ($filaProducto->productoDescripcion);?></td>
            
            <td>

            <button onclick="location.href='actualizarProducto.php?productoCodigo=<?php echo ($filaProducto->productoCodigo);?>'">Actualizar</button>
            <a href="../../controladores/controladorProducto.php?codigoClienteE=<?php echo $filaProducto->productoCodigo;?>">
            <button type="button" class="btn btn-danger" onclick ="return confirmar()">
            Eliminar
            </button>
            </a>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>  
    </div>

    <script type="text/javascript">
      function confirmar(){
        var respuesta = confirm ("¿quieres eliminar el producto?");
        if (respuesta==true){
          return true;
        }
        else {
          return false;
        }
      }

    </script>
     
  
  
    <div class='swanky_title__social'>
    <a href='../menu/menuPrincipal.php'>
        <div class=''>
          <div class='arrow'>
            <div class='stem'></div>
            <div class='point'></div>
          </div>
        </div>
        <img src='https://cdn-icons-png.flaticon.com/512/6927/6927593.png'>
           Menu
      </a>
    </div>
    <div class='swanky_title__social'>
    <a href='../../controladores/controladorCerrarSesion.php'>
        <div class=''>
          <div class='arrow'>
            <div class='stem'></div>
            <div class='point'></div>
          </div>
    </div>
    <img src='https://cdn-icons-png.flaticon.com/512/8566/8566237.png'>
        Regresar
      </a>
    </div>
  </div>
  <!-- /////////// Begin Dropdown //////////// -->
  <div class='swanky_wrapper'>
    <input id='Dashboard' name='radio' type='radio'>
    <label for='Dashboard'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/dash.png'>
      <span>Gestionar Usuario</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
      <ul>
        <a href="../usuarios/insertarUsuario.php"><li>Crear Usuario</li></a>
        <a href="../usuarios/listarUsuario.php"><li>Consultar Usuario</li></a>
        <a href="../usuarios/actualizarUsuario.php"> <li>Editar Usuario</li></a>
        <a href="../usuarios/listarUsuario.php"> <li>Eliminar Usuario</li></a>
        </ul>
      </div>
    </label>
    <input id='Sales' name='radio' type='radio'>
    <label for='Sales'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/del.png'>
      <span>Gestionar Ventas</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
      <ul>
          <a href="../ventas/insertarVenta.php"><li>Crear Ventas</li></a>
          <a href="../ventas/listarVenta.php"><li>Consultar Ventas</li></a>
          <a href="../ventas/actualizarVenta.php"><li>Editar Ventas</li></a>
          <a href="../ventas/listarVenta.php"><li>Eliminar Ventas</li></a>
        </ul>
      </div>
    </label>
    <input id='Messages' name='radio' type='radio'>
    <label for='Messages'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/mess.png'>
      <span>Gestionar Productos</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
      <ul>
        <a href="../producto/insertarProducto.php"><li>Crear Productos</li></a>
          <a href="../producto/listarProducto.php"><li>Consultar Productos</li></a>
          <a href="../producto/actualizarProducto.php"><li>Editar Productos</li><li>Editar Productos</li>
          <a href="../producto/listarProducto.php"><li>Eliminar Productos</li></a>
          
        </ul>
      </div>
    </label>
    <input id='Users' name='radio' type='radio'>
    <label for='Users'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/mess.png'>
      <span>Gestionar Clientes</span>
      <div class='lil_arrow'></div>
      <div class='bar'></div>
      <div class='swanky_wrapper__content'>
      <ul>
          <li><button style="background-color: #15a3f9; border-style: none;" onclick="window.location='../clientes/insertarCliente.php'">Crear Cliente</button></li> 
          <li><button style="background-color: #15a3f9; border-style: none;" onclick="window.location='../clientes/listarCliente.php'">Consultar Cliente</button></li>
          <li><button style="background-color: #15a3f9; border-style: none;" onclick="window.location='../clientes/actualizarCliente.php'">Editar cliente</button></li>
          <li><button style="background-color: #15a3f9; border-style: none;" onclick="window.location='../clientes/actualizarCliente.php'">Eliminar cliente</button></li>
        </ul>
      </div>
    </label>
    
  </div>
    
  </div>
  <!-- /////////// End Dropdown //////////// -->
</div>

</body>
</html>