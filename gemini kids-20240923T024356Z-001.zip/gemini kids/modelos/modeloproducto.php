<?php

include('modeloConexion.php'); 

class modeloProducto extends modeloConexion{
    //ATRIBUTOS 
    private $productoCodigo = 0; 
    private $productoNombre = "texto"; 
    private $productoPrecioVenta = 0; 
    private $productoUnidadMedida= "texto"; 
    private $productostock="texto";
    private $productoDescripcion = "texto"; 

    //METODO CONSTRUCTOR - ENCAPSULAR 
    public function __construct($codProdIn, $nomProdIn, $precProdIn, $medidaProdIn,$stockProdIn, $descProdIn)
    {
        $this->productoCodigo = $codProdIn; 
        $this->productoNombre = $nomProdIn; 
        $this->productoPrecioVenta = $precProdIn; 
        $this->productoUnidadMedida= $medidaProdIn;
        $this->productostock= $stockProdIn;
        $this->productoDescripcion = $descProdIn;
    }

    //METODOS CLASE 
    public function registrarProducto()
    {
        $objConexion = new modeloConexion(); 
        $objPDO = $objConexion::conectar();
        
        try {
            $sql = $objPDO->prepare("INSERT INTO producto VALUES
                                        (
                                            :codigoProducto,
                                            :nombreProducto,
                                            :precioVentaProducto,
                                            :unidadMedidaProducto,
                                            :stockProducto,
                                            :descripcionProducto
                                        );"); 
            $sql->bindparam(':codigoProducto',$this->productoCodigo); 
            $sql->bindparam(':nombreProducto',$this->productoNombre);
            $sql->bindparam(':precioVentaProducto',$this->productoPrecioVenta);
            $sql->bindparam(':unidadMedidaProducto',$this->productoUnidadMedida);
            $sql->bindparam(':stockProducto',$this->productostock); 
            $sql->bindparam(':descripcionProducto',$this->productoDescripcion);

            $sql->execute(); 

            $objPDO = $objConexion::desconectar(); 

        } catch (\Throwable $error) {
            echo("Error modelo!; ".$error->getMessage());
            die();
        }
    }

//listar Producto
    function listarProducto(){
        $objConexion = new modeloConexion();
        $objPDO = $objConexion::conectar();
                                            
         try {
            $sql= $objPDO->prepare("SELECT * FROM producto"); 
    
              $sql->execute();
              return $sql->fetchAll(PDO::FETCH_OBJ);
    
               $objPDO=$objConexion::desconectar();
         }
             
         
           catch(\Throwable $error){
               echo'ERROR:'. $error -> getMessage();
               die();
               
           }
           
    }

   

    //actualizar producto
    public function consultarProducto(){ 
        $objConexion = new modeloConexion(); 
        $objPDO = $objConexion::conectar();

        try {
    
            $sql = $objPDO->prepare("SELECT * FROM producto
                                    WHERE productoCodigo=:productoCodigo");
            
            $sql->bindparam(':productoCodigo', $this->productoCodigo);
            
            $sql->execute(); 

            return $sql->fetchAll(PDO::FETCH_OBJ);
            
            $objPDO= $objConexion::desconectar(); 
        }
    
        catch (\Throwable $error) {
            echo 'ERROR: '. $error->getMessage();          
            die();
        }
    
    }

    //
    public function actualizarProducto(){
        $objConexion= new modeloConexion();
        $objPDO=$objConexion::conectar();
        try{
            $sql=$objPDO->prepare("UPDATE producto SET
                                     productoNombre=:productoNombre,
                                     productoPrecioVenta=:productoPrecioVenta,
                                     productoUnidadMedida=:productoUnidadMedida,
                                     productostock=:productostock,
                                     productoDescripcion=:productoDescripcion
                                    WHERE productoCodigo=:productoCodigo;");
            $sql->bindparam(':productoCodigo',$this->productoCodigo);
            $sql->bindparam(':productoNombre',$this->productoNombre);
            $sql->bindparam(':productoPrecioVenta',$this->productoPrecioVenta);
            $sql->bindparam(':productoUnidadMedida',$this->productoUnidadMedida);
            $sql->bindparam(':productostock',$this->productostock);
            $sql->bindparam(':productoDescripcion',$this->productoDescripcion);
            
            $sql->execute();

            $objPDO = $objConexion::desconectar();
    } catch (\Throwable $error) {
        echo 'ERROR: '. $error->getMessage();          
        die();
    }
    
    }

     //eliminar 
     public function eliminarProducto(){
        $objConexion= new modeloConexion();
        $objPDO=$objConexion::conectar();
    
        try {
            $sql = $objPDO->prepare("DELETE FROM producto 
                                        WHERE productoCodigo = :productoCodigo;");
            $sql->bindparam(':productoCodigo',$this->productoCodigo);
            $sql->execute();
            $objPDO=$objConexion::desconectar();
        }   catch(\Throwable$error){
            echo'ERROR:'.$error->getMessage();
            die();
        }    
    }
}
      

        
    

    
        
           

?>
