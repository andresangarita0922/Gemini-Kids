<?php
include ('modeloConexion.php');
class modeloVenta extends modeloConexion
{
    //ATRIBUTOS
    private $ventaCodigoV;
    private $fechaVentaV;
    private $cantidadVentaV;
    private $ventaTotalV;
    private $codigoVendedorV;
    private $codigoClienteV;


    //METODO CONSTRUCTOR
    function __construct($ventaCodigoIn, $fechaVentaIn, $cantidadVentaIn,$ventaTotalIn, $codigoVendedorIn,
                        $codigoClienteIn)
    {
            $this->ventaCodigoV = $ventaCodigoIn;
            $this->fechaVentaV = $fechaVentaIn;
            $this->cantidadVentaV = $cantidadVentaIn;
            $this->ventaTotalV = $ventaTotalIn;
            $this->codigoVendedorV = $codigoVendedorIn;
            $this->codigoClienteV = $codigoClienteIn;        
    }
//INSERTAR
    public function insertarVenta(){
        $objConexion = new modeloConexion();
        $objPDO = $objConexion::conectar();
    
        try {
            $sql = $objPDO->prepare("CALL insertarVenta
                                        (:ventaCodigoV,
                                         :fechaVentaV,
                                         :cantidadVentaV,
                                         :ventaTotalV,
                                         :codigoVendedorV,
                                         :codigoClienteV);");
            $sql->bindparam(':ventaCodigoV',$this->ventaCodigoV);
            $sql->bindparam(':fechaVentaV',$this->fechaVentaV);
            $sql->bindparam(':cantidadVentaV',$this->cantidadVentaV);
            $sql->bindparam(':ventaTotalV',$this->ventaTotalV);
            $sql->bindparam(':codigoVendedorV',$this->codigoVendedorV);
            $sql->bindparam(':codigoClienteV',$this->codigoClienteV);
    
            $sql->execute();
    
            $objPDO = $objConexion::desconectar();
        } catch (\Throwable $error) {
            echo 'ERROR: '. $error->getMessage();
            die();
        }
    }
    //LISTAR VENTA
    function consultarVenta(){
        $objConexion = new modeloConexion();
        $objPDO = $objConexion::conectar();
                                            
         try {
            $sql= $objPDO->prepare("CALL listarVenta"); 
    
              $sql->execute();
              return $sql->fetchAll(PDO::FETCH_OBJ);
    
               $objPDO=$objConexion::desconectar();
         }
             
         
           catch(\Throwable $error){
               echo'ERROR:'. $error -> getMessage();
               die();
               
           }
           
    }
         //ACTUALIZAR VENTA
         public function consultarVentaxID(){ 
            $objConexion = new modeloConexion(); 
            $objPDO = $objConexion::conectar();
    
            try {
        
                $sql = $objPDO->prepare("CALL consultarxId(:codigoVenta);");
                
                $sql->bindparam(':codigoVenta', $this->ventaCodigoV);
                
                $sql->execute(); 
    
                return $sql->fetchAll(PDO::FETCH_OBJ);
                
                $objPDO= $objConexion::desconectar(); 
            }
        
            catch (\Throwable $error) {
                echo 'ERROR: '. $error->getMessage();          
                die();
            }
        
        }
    
        public function actualizarVenta(){
            $objConexion = new modeloConexion();
            $objPDO = $objConexion::conectar();
        
            try {
                $sql = $objPDO->prepare("CALL actualizarVenta
                                            (:ventaCodigoV,
                                             :fechaVentaV,
                                             :cantidadVentaV,
                                             :ventaTotalV,
                                             :codigoVendedorV,
                                             :codigoClienteV);");
                $sql->bindparam(':ventaCodigoV',$this->ventaCodigoV);
                $sql->bindparam(':fechaVentaV',$this->fechaVentaV);
                $sql->bindparam(':cantidadVentaV',$this->cantidadVentaV);
                $sql->bindparam(':ventaTotalV',$this->ventaTotalV);
                $sql->bindparam(':codigoVendedorV',$this->codigoVendedorV);
                $sql->bindparam(':codigoClienteV',$this->codigoClienteV);
        
                $sql->execute();
        
                $objPDO = $objConexion::desconectar();
            } catch (\Throwable $error) {
                echo 'ERROR: '. $error->getMessage();
                die();
            }
        }
            //ELIMINAR
     public function eliminarVenta(){
        $objConexion= new modeloConexion();
        $objPDO=$objConexion::conectar();
    
        try {
            $sql = $objPDO->prepare("CALL eliminarVenta
                                     (:ventaCodigo);");
            $sql->bindparam(':ventaCodigo',$this->ventaCodigoV);
            $sql->execute();
            $objPDO=$objConexion::desconectar();
        }   catch(\Throwable$error){
            echo'ERROR:'.$error->getMessage();
            die();
        }    
    }
}

?>