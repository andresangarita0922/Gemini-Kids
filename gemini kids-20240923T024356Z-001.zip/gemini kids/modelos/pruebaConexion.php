<?php

include('modeloConexion.php');

$objConexion=new modeloConexion();

try{
    $objConexion->conectar();
    $objConexion->desconectar();
    echo("SE CONECTO CORRECTAMENTE");
} catch (\Throwabla $error){
    echo("ERROR". $error->getMessage(). "<br>");
    die();
}
?>