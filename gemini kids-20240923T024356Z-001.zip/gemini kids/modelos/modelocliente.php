<?php

include('modeloConexion.php'); 

class modeloCliente extends modeloConexion{
    //ATRIBUTOS 
    private $idCliente = 0; 
    private $tipoIdentificacionCliente= "texto"; 
    private $nombreCliente = "texto"; 
    private $telefonoCliente= 0; 
    private $direccionCliente="texto";
    private $telefonoCliente2 = 0; 
    private $correoCliente = "texto"; 

    //METODO CONSTRUCTOR - ENCAPSULAR 
    public function __construct($idClien, $tipCliente, $nomCliente, $telCliente,$direCliente, $tel2Cliente,$corrCliente)
    {
        $this->idCliente=$idClien ;
        $this->tipoIdentificacionCliente=$tipCliente ;
        $this->nombreCliente=$nomCliente ;
        $this->telefonoCliente=$telCliente ;
        $this->direccionCliente=$direCliente;
        $this->telefonoCliente2=$tel2Cliente ;
        $this->correoCliente=$corrCliente;

    }

    //METODOS CLASE 
    public function insertarCliente(){
        $objConexion = new modeloConexion(); 
        $objPDO = $objConexion::conectar();

        try {
            $sql = $objPDO->prepare("CALL insertarCliente(
                                        :idCliente,
                                        :tipoIdentificacionCliente,
                                        :nombreCliente, 
                                        :telefonoCliente, 
                                        :direccionCliente, 
                                        :telefonoCliente2, 
                                        :correoCliente     
                                    )"); 
            $sql->bindparam(':idCliente',$this->idCliente);     
            $sql->bindparam(':tipoIdentificacionCliente',$this->tipoIdentificacionCliente); 
            $sql->bindparam(':nombreCliente',$this->nombreCliente); 
            $sql->bindparam(':telefonoCliente',$this->telefonoCliente); 
            $sql->bindparam(':direccionCliente',$this->direccionCliente); 
            $sql->bindparam(':telefonoCliente2',$this->telefonoCliente2); 
            $sql->bindparam(':correoCliente',$this->correoCliente); 

            $sql->execute(); 
            
            $objPDO = $objConexion::desconectar(); 

        } catch (\Throwable $error) {
            echo("Error modelo!; ".$error->getMessage());
            die();
        }
    }
    //LISTAR CLIENTE
    function listarCliente(){
        $objConexion = new modeloConexion();
        $objPDO = $objConexion::conectar();
                                            
         try {
            $sql= $objPDO->prepare("SELECT * FROM v_listarcliente"); 
    
              $sql->execute();
              return $sql->fetchAll(PDO::FETCH_OBJ);
    
               $objPDO=$objConexion::desconectar();
         }
             
         
           catch(\Throwable $error){
               echo'ERROR:'. $error -> getMessage();
               die();
               
           }
           
    }

    
    //ACTUALIZAR CLIENTE
    public function consultarClientes(){ 
        $objConexion = new modeloConexion(); 
        $objPDO = $objConexion::conectar();

        try {
    
            $sql = $objPDO->prepare("SELECT * FROM v_listarcliente
                                    WHERE =:codigoCliente=codigoCliente");
            
            $sql->bindparam(':codigoCliente', $this->codigoCliente);
            
            $sql->execute(); 

            return $sql->fetchAll(PDO::FETCH_OBJ);
            
            $objPDO= $objConexion::desconectar(); 
        }
    
        catch (\Throwable $error) {
            echo 'ERROR: '. $error->getMessage();          
            die();
        }
    
    }

    //
    public function actualizarCliente(){
        $objConexion= new modeloConexion();
        $objPDO=$objConexion::conectar();
        try{
            $sql=$objPDO->prepare("UPDATE cliente SET
                                    tipoIdentificacionCliente=:tipoIdentificacionCliente,
                                    nombreCliente=:nombreCliente,
                                    telefonoCliente=:telefonoCliente,
                                    direccionCliente=:direccionCliente,
                                    telefonoCliente2=:telefonoCliente2,
                                    correoCliente=:correoCliente
                                    WHERE idCliente =:idCliente;");
             $sql->bindparam(':idCliente',$this->idCliente);     
             $sql->bindparam(':tipoIdentificacionCliente',$this->tipoIdentificacionCliente); 
             $sql->bindparam(':nombreCliente',$this->nombreCliente); 
             $sql->bindparam(':telefonoCliente',$this->telefonoCliente); 
             $sql->bindparam(':direccionCliente',$this->direccionCliente); 
             $sql->bindparam(':telefonoCliente2',$this->telefonoCliente2); 
             $sql->bindparam(':correoCliente',$this->correoCliente); 
            
            $sql->execute();

            $objPDO = $objConexion::desconectar();
    } catch (\Throwable $error) {
        echo 'ERROR: '. $error->getMessage();          
        die();
    }
    
    }

     //ELIMINAR 
     public function eliminarCliente(){
        $objConexion= new modeloConexion();
        $objPDO=$objConexion::conectar();
    
        try {
            $sql = $objPDO->prepare("DELETE FROM cliente
                                        WHERE idCliente = :idCliente;");
            $sql->bindparam(':idCliente',$this->idCliente);
            $sql->execute();
            $objPDO=$objConexion::desconectar();
        }   catch(\Throwable$error){
            echo'ERROR:'.$error->getMessage();
            die();
        }    
    }



 }