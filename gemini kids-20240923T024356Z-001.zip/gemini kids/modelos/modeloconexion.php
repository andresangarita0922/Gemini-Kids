<?php

class modeloConexion {
    //ARTRIBUTOS
    private $bdhost = 'localhost'; 
    private $bdnombre = 'proyecto04'; 
    private $usuario = 'root'; 
    private $bdContrasena = ''; 

    //METODOS 
    public function conectar(){
        $objPDO = new PDO('localhost='.$this->bdhost.';dbname='.$this->bdnombre.';
                            charset=utf8',$this->usuario,$this->bdContrasena); 
        $objPDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
        return $objPDO; 
    }

    public function desconectar(){
        return null; 
    }
}
     
?>