create database proyecto04;
use proyecto04;

create table usuario(
codigo int auto_increment primary key not null,
nombre varchar(32) not null,
clave varchar(32) not null,
tipoUsuario varchar(20) not null);


create table administrador(
codigo int auto_increment primary key not null,
identificacion varchar(20) not null,
tipoIdentificacion varchar(15) not null,
nombre varchar (50) not null,
apellido varchar (50) not null,
celular varchar (20) not null,
direccion varchar (50) not null,
u_codigo_fk  int not null);

create table cliente(
codigo int auto_increment primary key not null,
identificacion varchar(20) not null,
tipoidentificacion varchar(15) not null,
nombre Varchar(50) not null,
apellido Varchar(50) not null,
celular Varchar(20) NOT NULL,
direccion Varchar(50) NOT NULL,
c_codigo_fk int not null);


create table venta(
codigo int auto_increment primary key not null,
fecha date not null,
total int not null,
cantidadtotal int not null,
c_codigo_fk int not null,
v_codigo_fk int not null);

create table detalle_venta(
codigo int auto_increment primary key not null,
subtotal int not null,
cantidadproducto int not null,
v_codigo_fk int not null,
p_codigo_fk int not null);

create table producto(
codigo int auto_increment primary key not null,
nombre varchar(50) not null,
precioventa int not null,
cantidadstock int not null,
unidadmedida varchar(50) not null,
descripcion  text not null);

alter table administrador 
add constraint admusu
foreign key(u_codigo_fk)
references usuario (codigo);

alter table cliente
add constraint cliusu
foreign key (c_codigo_fk)
references usuario (codigo);

alter table detalle_venta
add constraint detpro
foreign key (p_codigo_fk)
references producto (codigo);

alter table detalle_venta
add constraint vendet
foreign key(v_codigo_fk)
references venta (codigo);

alter table venta 
add constraint vencli
foreign key (c_codigo_fk)
references cliente (codigo);

alter table venta
add constraint venadm
foreign key (v_codigo_fk)
references administrador (codigo);

insert into usuario(nombre,clave,tipoUsuario)
values ('andres','cssja','cliente'),
('beto','vbbha','cliente'),
 ('leidy','poqad','administrador'),
 ('daniel','pgods','cliente'),
('samuel','njfcnvjhg','cliente'),
('sol','njhfvbhcvhgf','cliente'),
('angie','jhncvnbfch','cliente'),
('luna','jdncnvc jfv','cliente'),
('esteban','mcnvcbvh','cliente'),
('sharon','ncvjuhfhj','cliente'),
('dayan','qieifjndfe','cliente'),
('fabian','nvnviffifd','cliente'),
('jeferson','cnbchjfcj','cliente'),
('pabon','15896359','cliente'),
('cesar','nmvjhgvfujfju','cliente');


insert into administrador(identificacion,tipoIdentificacion,nombre,apellido,celular,direccion,u_codigo_fk )
values ('869754','cc','leidy','sichaca','3223507394','cra 2 bis 41b 63 sur',3);

	


insert into cliente(identificacion,tipoidentificacion,nombre,apellido,celular,direccion,c_codigo_fk)
values ('89806','cc','andres','angarita','3128678902','cra 6 norte',1),
('87542','cc','fabian','roa','3138562011','cra 26 sur',12),
('67349','cc ','luna','ballen','3145467897','cra 45 sur',8),
('58796','cc','beto','diaz','3125478914','calle 65 sur',2),
('25678','cc','angie','gutierrez','3149406734','calle 29 sur',7),
('91675','cc','pabon','veloza','3208647596','cra 27 sur',14),
('54787','cc','cesar','gomez','3109785634','calle 4 sur',15),
('24155','cc','samuel','rodriguez','31578941485','calle 52 sur',5),
('58796','cc','jeferson','sanchez','3109876543','calle 22 sur',13),
('82156','cc','sol','tevez','313547982','calle 100 norte',6),
('12365','cc','dayan','orlando','3109876459','calle 2 sur',11),
('14327','cc','sharon','martinez','3105678902','cra 4 sur',10),
('85678','cc','daniel','jimenez','3138576321','calle 19 sur',4);


insert into producto(nombre,precioventa,cantidadstock,unidadmedida,descripcion)
values('medias','50000','3','30 m','25698'),
('camiseta','30000','5','450 m','52694'),
('patalon','40000','9','540 m','69750'),
('ropa interior','10000','8','489 m','78459'),
('saco','20000','14','598 m','14780'),
('camisas deportivas','18000','13','50 m','56987'),
('jeans','96000','15','40 m','54123'),
('busos','300000','6','145 m','68951'),
('chalecos','87000','12','587 m','15692'),
('sudaderas','20000','7','10 m','25896'),
('overol','100000','2','400 m','45876'),
('faldas','10000','11','300 m','14562'),
('vestidos','58000','1','40 m','45856');


insert into venta(fecha,total,cantidadtotal,c_codigo_fk,v_codigo_fk)
values ('2000/02/17',50000,3,1,1),
('2017/02/06',30000,5,2,1),
('2018/05/01',40000,3,1,1),
('2020/12/22',10000,8,2,1),
('2021/07/09',20000,14,1,1),
('2017/02/05',18000,13,2,1),
('2016/11/01',96000,15,1,1),
('2014/12/03',300000,6,2,1),
('2013/01/01',87000,12,1,1),	
('2012/02/03',20000,7,2,1),
('2011/04/05',100000,2,1,1),
('2020/01/09',10000,11,2,1),
('2019/02/08',58000,1,1,1);


insert into detalle_venta(subtotal,cantidadproducto,v_codigo_fk,p_codigo_fk)
values(50000,3,1,1),
(30000,5,2,2),
(40000,3,3,3),
(10000,8,4,4),
(20000,14,5,5),
(18000,13,6,6),
(96000,15,7,7),

(300000,6,8,8),
(87000,12,9,9),

(20000,7,10,10),
(100000,2,11,11),
(10000,11,12,12),
(58000,1,13,13);

